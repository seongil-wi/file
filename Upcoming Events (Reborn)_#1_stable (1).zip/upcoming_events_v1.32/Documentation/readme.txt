Upcoming Events

Shows upcoming calendar events at the forum index and the portal page.

Version: 1.31
Author: lorus
Submitted: 14th April 2011
Last Updated: 10th May 2011

Description:

This plugin shows upcoming calendar events at the forum index, inside the board stats box and/or at the portal page (portal.php).

Features:

    upcoming events box at index and portal page
    recognizes MyBB time & date settings (global and user specific)
    scalable display options (time range and max. entries)


Version: 1.32

Author: lorus & Vintagedaddyo

Submitted: 4th March 2019

Last Updated: 4th March 2019 by Vintagedaddyo



Updated to version 1.32 for MyBB 1.8.x usage by: Vintagedaddyo

- Minor code changes for 1.8 compatibility & localization completion

- added missing calendar image and changed from gif to png

- added license and readme files in new documents directory

- Localization:

- english
- englishgb
- espanol
- french
- italiano

Compatibility:

MyBB 1.8: Yes 


To Install:

Upload The Files, And Go to Admin CP And Active IT!