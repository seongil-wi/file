<?php
require("includes/global.php");

$pageInfo['title'] = "Register";

fetchTemplate("header");

$do = @$_GET['do'];
if ($do == "") {
 fetchTemplate("register");
}
else if ($do == "reg") {
 $error = "";
 $user = addslashes(htmlentities(@$_POST['user']));
 $pass = addslashes(htmlentities(@$_POST['pass']));
 $email = addslashes(htmlentities(@$_POST['email']));
 $fname = addslashes(htmlentities(@$_POST['fname']));
 $lname = addslashes(htmlentities(@$_POST['lname']));
 $aim = addslashes(htmlentities(@$_POST['aim']));
 $msn = addslashes(htmlentities(@$_POST['msn']));
 $yim = addslashes(htmlentities(@$_POST['yim']));
 $icq = addslashes(htmlentities(@$_POST['icq']));
 $sig = addslashes(htmlentities(@$_POST['sig']));
 $avat = addslashes(htmlentities(@$_POST['avat']));
 $txtSecurity = addslashes(htmlentities(@$_POST['txtSecurity']));
 if ($user && $pass && $email && $txtSecurity) {
  $query = mysql_query("SELECT `username` FROM `users` WHERE username='$user'");
  $q = mysql_fetch_row($query);
  if (strlen($user) > 12) {
   $error =  "Sorry the username, <i>".stripslashes($user)."</i>, is too long. It may only be 12 or less characters long.";
  }
  else if (strlen($pass) > 12) {
   $error = "Sorry, your password is too long. It may be only 12 or less characters long.";
  }
  else if (strlen($sig) > 750) {
   $error = "Sorry, but your signature may only be 750 characters or less.";
  }
  else if (preg_chars("/^[A-Za-z0-9_]+$/", $user)) {
   $error = "You have invalid charactors in your username. Valid charactors are a-z, A-Z, 0-9, and the _ (underscore). Usernames are all case-insensitive!";
  }
  else if (preg_chars("/^[A-Za-z0-9_]+$/", $pass)) {
   $error = "You have invalid charactors in your password. Valid charactors are a-z, A-Z, 0-9, and the _ (underscore).";
  }
  else if (!isValidEmail($email)) {   // added by roshith on 9-8-06
   $error = "Your Email is invalid.";
  }
  else if ($q) {
   $error = "That username has already been taken.";
  }
  else 
  {
		if(($_SESSION['captchastr']==$txtSecurity) && $_SESSION['captchastr']!='' || 
			($_SESSION['captchastr_low']==$txtSecurity) && $_SESSION['captchastr_low']!='')
		{
  
		   $ip = @$_SERVER['REMOTE_ADDR'];
		   $pass = md5($pass);
		   $time = time();
		   $q = mysql_query("INSERT INTO `users` VALUES ('','$user','$pass','$email','$fname','$lname','$aim','$msn','$yim','$icq','$avat','$sig','0','$ip','Member','Member','$time')");
		   if ($q) 
		   {
				if ($fname)
				 {
					 echo "<p align=center><font color=red>Thank you, ".$fname.", you are now registered!<br /></font></p>\n";
					 echo "<p align=center><a href=\"index.php\">".$pageInfo['sitename']." Home</a><br /></p>\n";
				 }//edn if
				else 
				{
					 echo "<p align=center><font color=red>Thank you, ".$user.", you are now registered!<br /></font></p>\n";
					 echo "<p align=center><a href=\"index.php\">".$pageInfo['sitename']." Home</a><br /></p>\n";
				}//end else
		   }//end if
		   else 
		   {
				$error = "Unable to register new user.<br /><br />\n".mysql_error()."<br /><br />\nPlease report this error to the administrator.";
		   }//end else
		}//end if
		else
		{
			$error = "Invalid Security Code.";
		}//end else
  }//end else
 }
 else {
  $error = "Please fill in all of the required fields (username, password, e-mail, and security code).";
 }
 if ($error) {
  $error .= "<br /><br />\n<a href=\"register.php\">[ Back ]</a><br /><br />\n";
  echo "<br><p align=center><font color=red>".$error."</font></p>";
 }
}

fetchTemplate("footer");
?>