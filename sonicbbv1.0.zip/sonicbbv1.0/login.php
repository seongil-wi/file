<?php
include("includes/global.php");

$pageInfo['title'] = "Login";

$redir = @$_GET['redir'];
if (!$redir) $redir = "index.php";

if (!$userInfo['loggedin']) {
 $do = @$_GET['do'];
 if ($do == "") {
  fetchTemplate("header");
  fetchTemplate("login");
  fetchTemplate("footer");
 }
 else if ($do == "login") {
  $error = "";
  $user = addslashes(htmlentities(@$_POST['user']));
  $pass = md5(addslashes(htmlentities(@$_POST['pass'])));
  $query = mysql_query("SELECT * FROM `users` WHERE username='$user' AND password='$pass'");
  $q = mysql_fetch_row($query);
  if (!$q[0]) {
   $error .= "Username and password do not match.<br />\n";
  }
  else {
   $_SESSION['loggedin'] = 1;
   $_SESSION['user'] = $user;
   header("Location: ".$redir);
  }
  if ($error) {
   fetchTemplate("header");
   echo "<br><p align=center><font color=red>".$error."</font></p>";
   echo "\n<p align=center><a href=\"login.php\">[ Back ]</a></p>\n";
   fetchTemplate("footer");
  }
 }
}
else {
 header("Location: index.php");
}
?>