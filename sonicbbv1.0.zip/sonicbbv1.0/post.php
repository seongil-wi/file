<?php
include("includes/global.php");

$p = @$_GET['p'];
if ($p == "") $p = 1;

$id = @$_GET['id'];
if (!$id) {
 header("Location: index.php");
}

$q = mysql_query("SELECT * FROM `posts` WHERE id='$id'");
$q = mysql_fetch_array($q);
$q2 = mysql_query("SELECT * FROM `threads` WHERE id='{$q['inThread']}'");
$q2 = mysql_fetch_array($q2);
$q3 = mysql_query("SELECT * FROM `forums` WHERE id='{$q2['inForum']}'");
$q3 = mysql_fetch_array($q3);
$locked = $q3['locked'];

$do = @$_GET['do'];

$pageInfo['title'] = "Post Options";
$pageInfo['homelink'] .= " -> <a href=\"viewforum.php?id={$q3['id']}\">{$q3['name']}</a>";
$pageInfo['homelink'] .= " -> <a href=\"viewthread.php?id={$q2['id']}\">{$q2['title']}</a>";
$pageInfo['homelink'] .= " -> <a href=\"post.php?id={$id}&do={$do}\">Post Options</a>";

if ($do == "") {
 header("Location: index.php");
}
else if ($locked && @$userInfo['title'] != "Administrator") {
 header("Location: index.php");
}
else if ($do == "delete") {
 if (!$userInfo['loggedin']) {
  header("Location: index.php");
 }
 else if (!$q) {
  header("Location: index.php");
 }
 else if ($userInfo['title'] == "Administrator" || $userInfo['id'] == $q['posterId']) {
  $q4 = mysql_query("SELECT * FROM `posts` WHERE inThread='{$q['inThread']}' order by id"); // added,  order by id
  $q4 = mysql_fetch_array($q4);

  fetchTemplate("header");

  if ($q4['id'] == $q['id']) {
   if (@$userInfo['title'] != "Administrator") {
    echo "<br />\n<p align=center><font color=red>You cannot delete this post as it is the first post in this thread.<br /></font></p>\n";
   }
   else {
//    $q5 = mysql_query("DELETE FROM `threads` WHERE id='{$q['inThread']}'");
    $q6 = mysql_query("DELETE FROM `posts` WHERE id='{$q['id']}'");
    if ($q5 && $q6) {
     echo "<br />\n<p align=center><font color=red>Post and thread deleted!<br /></font></p>\n";
    }
    else {
     echo "<br />\n<p align=center><font color=red>Unable to delete post and thread!<br /></font></p>\n";
    }
   }
  }
  else {
   $q5 = mysql_query("DELETE FROM `posts` WHERE id='$id'");
   if ($q5) {
    echo "<br />\n<p align=center><font color=red>Post deleted!<br /></font></p>\n";
   }
   else {
    echo "<br />\n<p align=center><font color=red>Unable to delete post!<br /></font></p>\n";
   }
  }
  fetchTemplate("footer");
 }
}
else if ($do == "edit") {
 if (!$userInfo['loggedin']) {
  header("Location: index.php");
 }
 else if (!$q) {
  header("Location: index.php");
 }
 else if ($userInfo['title'] == "Administrator" || $userInfo['id'] == $q['posterId']) {
  $go= @$_GET['go'];
  if ($go == "true") {
   $title = htmlspecialchars(@$_POST['title']);
   $msg = htmlspecialchars(@$_POST['post']);
   $title = stripslashes($title);
   $msg = stripslashes($msg);
   $title = format_chars($title);
   $msg = format_chars($msg);
   $txtSecurity = htmlspecialchars(@$_POST['txtSecurity']);
   if ($title && $msg && $txtSecurity) 
   {
	   if(($_SESSION['captchastr']==$txtSecurity) && $_SESSION['captchastr']!='' || 
				($_SESSION['captchastr_low']==$txtSecurity) && $_SESSION['captchastr_low']!='')
		{
			$q4 = mysql_query("SELECT * FROM `posts` WHERE inThread='{$q['inThread']}'");
			$q4 = mysql_fetch_array($q4);
			$newq = mysql_query("UPDATE `posts` SET title='$title', post='$msg' WHERE id='" . $q['id'] . "'");
			if ($q4['id'] == $q['id']) {
			 mysql_query("UPDATE `threads` SET title='$title' WHERE id='{$q['inThread']}'");
			}
			if ($newq) {
			 header("Location: viewthread.php?id={$q['inThread']}&p={$p}#post{$q['id']}");
			}
			else {
			 fetchTemplate("header");
			 echo "<p align=center><font color=red>Unable to edit post. Please try again later.<br />\n<a href=\"post.php?id={$q['id']}&do=edit\">[ Back ]</a><br /></font></p>\n";
			 fetchTemplate("footer");
			}
		}//end captcha if
	  	else
	  	{
	  		fetchTemplate("header");
			echo "<p align=center><font color=red>Invalid Security Code!<br /><br />\n<a href=\"post.php?id={$q['id']}&do=edit\">[ Back ]</a><br /></font></p>\n";
			fetchTemplate("footer");
		}//end else
    }
   else {
    fetchTemplate("header");
    echo "<p align=center><font color=red>Title or Post or Security Code is blank!<br /><br />\n<a href=\"post.php?id={$q['id']}&do=edit\">[ Back ]</a><br /></font></p>\n";
    fetchTemplate("footer");
   }
  }
  else {
   $id = $q['id'];
   $_POST['title'] = $q['title'];
   $_POST['post'] = $q['post'];
   $action = "post.php?id={$id}&do=edit&go=true&p={$p}";
   fetchTemplate("header");
   fetchTemplate("postform");
   fetchTemplate("footer");
  }
 }
}
?>