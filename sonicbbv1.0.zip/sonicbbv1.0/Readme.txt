********************************************************************************************
                        iScripts Sonicbb Bulletin Board Readme File
                                   August 16, 2006
********************************************************************************************
(c) Copyright Armia Systems,Inc 2005-08. All rights reserved.

This file contains information that describes the installation of iScripts Sonicbb Bulletin board 
You can find more help on the product and the installation in the /docs folder.


********************************************************************************************
Contents
********************************************************************************************
1.0 Introduction
2.0 Requirements
3.0 Installing iScripts Sonicbb Bulletin board


********************************************************************************************
1.0 Introduction
********************************************************************************************
This file contains important information you should read before installing iScripts Sonicbb 
Bulletin board.

The iScripts Sonicbb Bulletin board enables any web master to offer bulletin board
from his/her website/server.

For any support, visit us at http://www.iscripts.com/support/kb/


********************************************************************************************
2.0 Requirements
********************************************************************************************

The iScripts sonicbb Bulletin board is developed in PHP and the database is MySQL. 

The requirements can be summarized as given below:
	1. PHP 5.2x or 5.3x 
		You can get the latest PHP version at http://www.php.net/downloads.php
	2. MySQL >= 4.1

   Other Requirements for Trouble free installation/working

	* SendMail - (Yes)
	* PHP safe mode - (OFF)
	* PHP open_basedir - (OFF)


********************************************************************************************
3.0 Installing iScripts Sonicbb Bulletin board
********************************************************************************************

3.1) Unzip the entire contents to a folder of your choice.
	a)Upload the contents to the server to the desired folder using an FTP client.If you do not 			have a FTP client we suggest CoreFTP or FTPzilla

3.2) Set 'Write' permission (777 for linux server) to the following folders.

	a) sonicbbv1.0/forum/images
	b) sonicbbv1.0/forum/images/smileys

3.3) Provide 'Write' permission (777 for linux server) for the following file.

	a) sonicbbv1.0/forum/includes/mysql.php 

3.4) Run the following URL in your browser and follow the instructions.
		
	http://www.yoursitename/install/
		
	If you have unzipped the files in the root (home directory), you can access the 
	sonicbb at http://www.yoursitename
		
	You can also install the script in any directory under the root. For example if 
	you have unzipped the zip file in a directory like http://www.yoursitename/Sonicbb
	then you can access the Sonicbb site at http://www.yoursitename/Sonicbb
		
	In the installation step, please provide the site url as described above, without
	any trailing slashes.
		
	Make sure you enter the same license key you received at the time of purchase,in the 
	"License Key" field. The script would function only for the domain it is licensed.If 
	you cannot recall the license its also included in the email you received with subject: 		�iScripts.com software download link�.You can also get the license key from your user panel 
	at www.iscripts.com

3.5) Remove the 'Write' permission provided to the file 'sonicbbv1.0/forum/includes/mysql.php'.

3.6) Delete the 'install' folder. 

3.7) Change the settings to match your specific requirements login using administrator username and password 



	
