<?php
include("includes/global.php");

$p = @$_GET['p'];
if ($p == "") $p = 1;

$id = @$_GET['id'];
$do = @$_GET['do'];

if (!$id) {
 header("Location: index.php");
}

if (!$userInfo['loggedin']) {
 header("Location: login.php?redir=reply.php?id={$id}");
}

$query = mysql_query("SELECT * FROM `threads` WHERE id='$id'");
$q = mysql_fetch_array($query);
$query2 = mysql_query("SELECT * FROM `forums` WHERE id='{$q['inForum']}'");
$q2 = mysql_fetch_array($query2);
$locked = $q2['locked'];

if (!$q) {
 header("Location: index.php");
}

if ($locked && @$userInfo['title'] != "Administrator") {
 header("Location: index.php");
}

$pageInfo['title'] = "Reply";
$pageInfo['homelink'] .= " -> <a href=\"viewforum.php?id={$q2['id']}\">{$q2['name']}</a>";
$pageInfo['homelink'] .= " -> <a href=\"viewthread.php?id={$q['id']}\">{$q['title']}</a>";
$pageInfo['homelink'] .= " -> <a href=\"reply.php?id={$q['id']}\">Reply</a>";

if ($do == "") {
 fetchTemplate("header");
 if (!@$_POST['title']) {
  @$_POST['title'] = "Re: {$q['title']}";
 }
 $action = "reply.php?id={$id}&do=reply&p={$p}";
 fetchTemplate("postform");
 fetchTemplate("footer");
}
else if ($do == "reply") {
 $title = @$_POST['title'];
 $post = @$_POST['post'];
 $txtSecurity = @$_POST['txtSecurity'];
 if ($title && $post && $txtSecurity) 
 {
		 if(($_SESSION['captchastr']==$txtSecurity) && $_SESSION['captchastr']!='' || 
				($_SESSION['captchastr_low']==$txtSecurity) && $_SESSION['captchastr_low']!='')
		{
			  $title = htmlspecialchars($title);
			  $post = htmlspecialchars($post);
			  $title = stripslashes($title);
			  $post = stripslashes($post);
			  $title = format_chars($title);
			  $post = format_chars($post);
			  $date = time();
			  $query = mysql_query("INSERT INTO `posts` VALUES ('','$title','{$userInfo['id']}','$date','{$q['inForum']}','$id','$post')");
			  $lastID = mysql_insert_id();
			  if ($query) {
			   $query = mysql_query("SELECT `inForum` FROM `threads` WHERE id='$id'");
			   $q = mysql_fetch_row($query);
			   $query = mysql_query("SELECT * FROM `forums` WHERE id='$q[0]'");
			   $q = mysql_fetch_array($query);
			   $posts = $q['posts'] + 1;
			   mysql_query("UPDATE `forums` SET posts='$posts' WHERE id='{$q['id']}'");
			   $userPosts = $userInfo['posts'] + 1;
			   mysql_query("UPDATE `users` SET posts='$userPosts' WHERE id='{$userInfo['id']}'");
			   header("Location: viewthread.php?id={$id}&p={$p}#post{$lastID}");
			  }
			  else {
			   $title = stripslashes($title);
			   $post = stripslashes($post);
			   fetchTemplate("header");
			?>
			<p align=center><font color=red><b>Error:</b> Unable to make new reply. Please try again later.<br /></font></p>
			<form method="post" action="reply.php?id=<?php echo "{$id}&p={$p}"; ?>">
			 <input type="hidden" name="title" value="<?php echo $title; ?>">
			 <input type="hidden" name="post" value="<?php echo $post; ?>">
			 <input type="submit" value="Back">
			</form>
			<?php
			   fetchTemplate("footer");
			  }
		}//end captcha if
	  	else
	  	{
	  		fetchTemplate("header");
			?>
				<p align=center><font color=red>Invalid Security Code.<br /></font></p>
				<form method="post" action="reply.php?id=<?php echo "{$id}&p={$p}"; ?>">
				 <input type="hidden" name="title" value="<?php echo $title; ?>">
				 <input type="hidden" name="post" value="<?php echo $post; ?>">
				<p align=center> <input type="submit" value="Back">  </p>
				</form>
			<?php
			fetchTemplate("footer");
		}//end else
 }
 else {
  fetchTemplate("header");
?>
<p align=center><font color=red>Please fill in all of the fields.<br /></font></p>
<form method="post" action="reply.php?id=<?php echo "{$id}&p={$p}"; ?>">
 <input type="hidden" name="title" value="<?php echo $title; ?>">
 <input type="hidden" name="post" value="<?php echo $post; ?>">
<p align=center> <input type="submit" value="Back">  </p>
</form>
<?php
  fetchTemplate("footer");
 }
}
?>