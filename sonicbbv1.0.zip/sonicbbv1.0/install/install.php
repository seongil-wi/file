<?php
ini_set('display_errors', '0');
error_reporting(0);
set_time_limit(0);
$currentpath="../";
//$sitename="SonicBB";
$configfile = "../includes/mysql.php";

$configcontents = @fread(@fopen($configfile, 'r'), @filesize($configfile));
//echo "fff",$configcontents;
$pos = strpos($configcontents, "INSTALLED");
if ($pos === false) {;
} else {
    header("Location:../index.php");
	exit;
}

function ResizeImageTogivenWitdhAndHeight($file, $img_height, $img_width, $tosavefileas = null)
{
    if (!isset($tosavefileas)) {
        $tosavefileas = $file;
    }

    $img_temp = NewimageCreatefromtype($file);
    $black = @imagecolorallocate ($img_temp, 0, 0, 0);
    $white = @imagecolorallocate ($img_temp, 255, 255, 255);
    $font = 2;
    $cuurentimagewidth = @imagesx($img_temp);
    $cuurentimageheight = @imagesy($img_temp);

    list($originalwidth, $originalheight, $originaltype) = getimagesize($file);
    if ($originaltype == "1") { // gif
        $newwidth = $img_width;
        $newheight = $img_height;
        $tpcolor = imagecolorat($img_temp, 0, 0);
        // in the real world, you'd better test all four corners, not just one!
        $img_thumb = imagecreate($newwidth, $newheight);
        // $dest automatically has a black fill...
        imagepalettecopy($img_thumb, $img_temp);
        imagecopyresized($img_thumb, $img_temp, 0, 0, 0, 0, $newwidth, $newheight,
            @imagesx ($img_temp), @imagesy($img_temp));
        $pixel_over_black = imagecolorat($img_thumb, 0, 0);
        // ...but now make the fill white...
        $bg = imagecolorallocate($img_thumb, 255, 255, 255);
        imagefilledrectangle($img_thumb, 0, 0, $newwidth, $newheight, $bg);
        imagecopyresized($img_thumb, $img_temp, 0, 0, 0, 0, $newwidth, $newheight,
            @imagesx ($img_temp), @imagesy($img_temp));
        $pixel_over_white = imagecolorat($img_thumb, 0, 0);
        // ...to test if transparency causes the fill color to show through:
        if ($pixel_over_black != $pixel_over_white) {
            // Background IS transparent
            imagefilledrectangle($img_thumb, 0, 0, $newwidth, $newheight,
                $tpcolor);
            imagecopyresized($img_thumb, $img_temp, 0, 0, 0, 0, $newwidth,
                $newheight, @imagesx ($img_temp), @imagesy($img_temp));
            imagecolortransparent($img_thumb, $tpcolor);
            imagegif($img_thumb, $tosavefileas);
        } else // Background (most probably) NOT transparent
            imagegif($img_thumb, $tosavefileas);
    } else {
        $img_thumb = @imagecreatetruecolor($img_width, $img_height);
        @imagecopyresampled($img_thumb, $img_temp, 0, 0, 0, 0, $img_width, $img_height, @imagesx ($img_temp), @imagesy($img_temp));
        ReturnImagetype($img_thumb, $tosavefileas, $file);
    }
}
function ReturnImagetype($newImage, $newfile, $editimagefile)
{
    list($width, $height, $type, $attr) = @getimagesize($editimagefile);
    $jpgCompression = "90";
    if ($type == "1") { // gif
        $returnimage = @imagegif($newImage, $newfile);
    } else if ($type == "2") { // jpeg
        $returnimage = @imagejpeg($newImage, $newfile, $jpgCompression);;
    } else if ($type == "3") { // png
        $returnimage = @imagepng($newImage, $newfile);
    } else {
        $returnimage = "Not Supported";
    }
    return $returnimage;
}
function NewimageCreatefromtype($image)
{
    list($width, $height, $type, $attr) = @getimagesize($image);
    if ($type == "1") { // gif
        $returnimage = @imagecreatefromgif($image);
    } else if ($type == "2") { // jpeg
        $returnimage = @imagecreatefromjpeg($image);
    } else if ($type == "3") { // png
        $returnimage = @imagecreatefrompng($image);
    } else {
        $returnimage = "Not Supported";
    }
    return $returnimage;
}

function isValidUsername($str)
{
    if (trim($str) !="" ) {
          //if ( eregi ( "[^0-9a-zA-Z+_]", $str ) ) {
        if ( preg_match ( "/[^0-9a-zA-Z+_]/i", $str ) ) {
                         return false;
             }else{
                    return true;
         }
    }else{
                return false;
    }

}

function isValidTableName($str)
{
    if (trim($str) != "") {
        //if (eregi ("[^a-zA-Z+_]", $str)) {
        if (preg_match ("/[^a-zA-Z+_]/i", $str)) {
            return false;
        } else {
            return true;
        }
    } else {
        return false;
    }
}

function isValidEmail($email)
{
    $email = trim($email);
    if ($email == "")
        return false;
//    if (!eregi("^" . "[a-z0-9]+([_\\.-][a-z0-9]+)*" . // user
//            "@" . "([a-z0-9]+([\.-][a-z0-9]+)*)+" . // domain
//            "\\.[a-z]{2,}" . // sld, tld
//            "$", $email, $regs)
//            ) {
    if (!preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/',$email)){
           
        return false;
    } else {
        return true;
    }
}
function isNotNull($value)
{
    if (is_array($value)) {
        if (sizeof($value) > 0) {
            return true;
        } else {
            return false;
        }
    } else {
        if (($value != '') && (strtolower($value) != 'null') && (strlen(trim($value)) > 0)) {
            return true;
        } else {
            return false;
        }
    }
}

function isValidWebImageType($mimetype,$tempname)
{
	//check if its image file
	if (!getimagesize($tempname))
	{
		return false;
	}
	if(($mimetype=="image/pjpeg") || ($mimetype=="image/jpeg") || ($mimetype=="image/x-png")|| ($mimetype=="image/png")|| ($mimetype=="image/gif")|| 
		($mimetype=="image/x-windows-bmp")|| ($mimetype=="image/bmp") ){
		return true;
	}else{
		return false;
	}
}
function getFilePermission($file){
        $perm = fileperms($file);
        if($perm === false){
                return "0000";
        }else{
                return substr(sprintf('%o', $perm), -4);
        }

}
function stripslashes_deep($value){
        $value = is_array($value) ? array_map('stripslashes_deep', $value) : stripslashes($value);
        return $value;
}
function getServerOS()
{
	return strtoupper(substr(PHP_OS, 0, 3));
}

//set_magic_quotes_runtime(0);

if (get_magic_quotes_gpc()) {
    $_POST = array_map('stripslashes_deep', $_POST);
    $_GET = array_map('stripslashes_deep', $_GET);
    $_COOKIE = array_map('stripslashes_deep', $_COOKIE);
}
/*
$schemafile = "schema.sql";
$datafile = "data.sql";
$configfile = "../includes/config.php";

$configcontents = @fread(@fopen($configfile, 'r'), @filesize($configfile));
$pos = strpos($configcontents, "INSTALLED");
if ($pos === false) {;
} else {
    header("Location:./index.php");
}
  */
$fullurl = $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
if($_SERVER['HTTPS']=='on'){
        $http = "https://";
}else {
        $http = "http://";
}
$pos = strrpos($fullurl, "/");
if ($pos === false) { // note: three equal signs
    // not found...
} else {
    $fullurl = substr($fullurl, 0, $pos);
}
$fullurl = $http . $fullurl;
$txtSiteURL = $fullurl;

/* *********************************check server configuration *****************************************************/

  $val1 = ini_get("safe_mode");
  $val2 = ini_get("short_open_tag");
  $val3 = ini_get("file_uploads");
  $val4 = ini_get("open_basedir");

  $openbasedircheck="0" ;
  if((!empty($val4) || $val4==1) and  (!empty($val3) || $val3==1)){

            if($_POST["submittest"] == "Upload"){
                  $uploadpath=substr($_FILES['testupload']['tmp_name'],0,strlen($_FILES['testupload']['tmp_name'])-strlen(basename($_FILES['testupload']['tmp_name']))-1);

                      $val4=$val4.":"."  ";
                      $openbasedirarray=explode(":",$val4);

                      if(! in_array($uploadpath,$openbasedirarray)){
                        // echo "<br>&nbsp;&nbsp;".$ivf."Please add '$uploadpath' in your openbase directory ";

                      }else{
                         $openbasedircheck="1";
                      }
                  $_SESSION['sess_openbasedircheck']=$openbasedircheck;
            }
  }        else{
        $_SESSION['sess_openbasedircheck']="1";
  }
  if( (! empty($val1) || $val1==1) or  (empty($val2) || $val2 !=1) or (empty($val3) || $val3 !=1) or $_SESSION['sess_openbasedircheck'] !='1'){
           $serverconfiguration="FAILURE";
  }else{

         $serverconfiguration="OK";
  }


$installed = 'false';
$mysql_serv="localhost";
$do = @$_POST['do'];


 if ($do == "finish") {

    $mysql_user = addslashes(@$_POST['mysql_user']);
    $mysql_pass = addslashes(@$_POST['mysql_pass']);
    $mysql_data = addslashes(@$_POST['mysql_data']);
    $mysql_serv = addslashes(@$_POST['mysql_serv']);
    $txtLicenseKey = addslashes(@$_POST['txtLicenseKey']);
    $sitename = addslashes(@$_POST['sitename']);
    $admin_email = addslashes(@$_POST['admin_email']);
    $sitelogo = addslashes(@$_POST['sitelogo']);
    $admin_user = addslashes(@$_POST['admin_user']);
    $admin_pass = addslashes(@$_POST['admin_pass']);

	$OS	= getServerOS();

    $imagedir = "../images/";
	$smileydir = "../images/smileys/";

    $logofile 		= $_FILES['sitelogo'][0];
    $logofilename	= $_FILES['sitelogo']['name'];
	$logotempname	= $_FILES['sitelogo']['tmp_name'];
    $logofiletype 	= $_FILES['sitelogo']['type'];
	
    $logofilename_blank = $_FILES['sitelogo']['name'];

	if($logofilename_blank =="")
		$logofilename ="logo.jpg";

    $logoimagedest = $imagedir . $logofilename;
    $wmfilesmalldest = $imagedir . $wmfilesmallname;
    $wmfilebigdest = $imagedir . $wmfilebigname;

    $message = "";

    if (!isNotNull($mysql_user)) {
        $message .= " * Mysql User name is empty!" . "<br>";
        $error = true;
    }
/*    if (!isNotNull($mysql_pass)) {
        $message .= " * Mysql Password is empty!" . "<br>";
        $error = true;
    }
*/  if (!isNotNull($mysql_data)) {
        $message .= " * Database Name is empty!" . "<br>";
        $error = true;
    }
    if (!isNotNull($mysql_serv)) {
        $message .= " * Server Name is empty!" . "<br>";
        $error = true;
    }
    if (!isNotNull($txtLicenseKey)) {
        $message .= " * License key is empty!" . "<br>";
        $error = true;
    }
    if (!isNotNull($sitename)) {
        $message .= " * Site Name is empty!" . "<br>";
        $error = true;
    }

    if ($logofiletype != "") {
        if (!isValidWebImageType($logofiletype,$logotempname)) {
            $message .= " * Invalid Logo file ! Upload an image (jpg/gif/bmp/png)" . "<br>";
            $error = true;
        } else {
            if (file_exists($logoimagedest) && $logofilename_blank!="") {
                $message .= " * Logo file with the same name exists! Please rename the logo file and upload! " . "<br>";
                $error = true;
            }
        }
    }

    if (!isNotNull($admin_email)) {
        $message .= " * Admin Email is empty!" . "<br>";
        $error = true;
    } else {
        if (!isValidEmail($admin_email)) {
            $message .= " * Invalid Admin Email!" . "<br>";
            $error = true;
        }
    }

    if (!isNotNull($admin_user)) {
        $message .= " * Admin User Name is empty!" . "<br>";
        $error = true;
    } else{
                if(!isValidUsername($admin_user)){
                        $message .= " * Invalid Admin Login Name! Please use only alphabets (aA-zZ) and underscore ( _ )!" . "<br>";
                $error = true;
                }
        }

    if (!isNotNull($admin_pass)) {
        $message .= " * Admin Password is empty!" . "<br>";
        $error = true;
    }
	if($OS != "WIN"){
		if (!is_writable($imagedir) || !is_readable($imagedir) || !@file_exists("$imagedir".".")  ) {
			$error = true;
			$message .= " * Change the permission (chmod 777 for linux server) of 'images' folder<br>";
		}
		if (!is_writable($smileydir) || !is_readable($smileydir) || !@file_exists("$smileydir".".")  ) {
			$error = true;
			$message .= " * Change the permission (chmod 777 for linux server) of 'images/smileys' folder<br>";
		}
    }
	    $connection = @mysql_connect($mysql_serv, $mysql_user, $mysql_pass);
    if ($connection === false) {
        $error = true;
        $message .= " * Connection Not Successful! Please verify your database details!<br>";
    } else {
        $dbselected = @mysql_select_db($mysql_data, $connection);
        if (!$dbselected) {
            $error = true;
            $message .= " * Database could not be selected! Please verify your database details!<br>";
        }
    }
    //Php 5.4 fix
//    if(ini_get('safe_mode') and strtoupper(ini_get('safe_mode')) !="OFF"){//safe_mode is on
//            $error = true;
//            $message .= " * The script requires PHP with safe mode Off to work properly. Installation cannot continue! <br>";
//    }
  
	$include_dir = "../includes/";
    $mysqlfilepath = $include_dir."mysql.php";
/*    if (!is_writable($include_dir) || !is_readable($include_dir) || !@file_exists("$include_dir".".")  ) {
        $error = true;
        $message .= " * Change the permission of 'includes' folder in the root to 777 <br>";
    }
*/  
	if($OS == "LIN"){
		if (!is_writable($mysqlfilepath)) {
			$error = true;
			$message .= " * Change the permission (chmod 777 for linux server) of 'includes/mysql.php' file<br>";
		}
	}
    if ($error) {              
        $message = "<u><b>Please correct the following errors to continue:</b></u>" . "<br>" . $message;
        // echo $message;
    }else {

        $admin_pass = md5($admin_pass);

        $mysql_querys = array();
        $mysql_tnames = array();

        // MySQL Table: data
        $mysql_tnames[0] = "data";
        $mysql_querys[0] = "create table `data` (
       vLicenceKey varchar(200),		
       sitename varchar(200),
       defaultTheme varchar(200),
       bannerImg varchar(255),
       usersTimeout int(10),
       adminEmail varchar(255),
       lastAdminLogin int(10)
      );";

        // MySQL Table: users
        $mysql_tnames[1] = "users";
        $mysql_querys[1] = "create table `users` (
       id int(100) auto_increment,
       username varchar(200),
       password varchar(200),
       email varchar(200),
       fname varchar(200),
       lname varchar(200),
       aim varchar(200),
       msn varchar(200),
       yim varchar(200),
       icq varchar(200),
       avatar varchar(255),
       sig varchar(255),
       theme varchar(255),
       ip varchar(16),
       title varchar(255),
       subtitle varchar(255),
       reggedOn int(10),
       primary key(id)
      );";

        // MySQL Table: cats
        $mysql_tnames[2] = "cats";
        $mysql_querys[2] = "create table `cats` (
       id int(100) auto_increment,
       name varchar(100),
       catOrder int(100),
       primary key(id)
      );";

        // MySQL Table: forums
        $mysql_tnames[3] = "forums";
        $mysql_querys[3] = "create table `forums` (
       id int(100) auto_increment,
       name varchar(200),
       discription varchar(255),
       inCat int(100),
       locked int(1),
       forumOrder int(100),
       primary key(id)
      );";

        // MySQL Table: threads
        $mysql_tnames[4] = "threads";
        $mysql_querys[4] = "create table `threads` (
       id int(100) auto_increment,
       title varchar(255),
       posterId int(100),
       date int(10),
       views int(100),
       inForum int(100),
       sticky int(1),
       primary key(id)
      );";

        // MySQL Table: posts
        $mysql_tnames[5] = "posts";
        $mysql_querys[5] = "create table `posts` (
       id int(100) auto_increment,
       title varchar(255),
       posterId int(100),
       date int(10),
       inForum int(100),
       inThread int(100),
       post text,
       primary key(id)
      );";

        // MySQL Table: online
        $mysql_tnames[6] = "online";
        $mysql_querys[6] = "create table `online` (
       id int(100) auto_increment,
       username varchar(200),
       date int(10),
       primary key(id)
      );";

        // MySQL Table: bannedips
        $mysql_tnames[7] = "bannedips";
        $mysql_querys[7] = "create table `bannedips` (
       id int(100) auto_increment,
       ip varchar(16),
       primary key(id)
      );";

        // MySQL Query: forum data
        $mysql_tnames[8] = "forum data";
        $mysql_querys[8] = "INSERT INTO `data` VALUES ('$txtLicenseKey','$sitename','SonicSilver','$logofilename','5','$admin_email','0')";

        // MySQL Query: test category
        $mysql_tnames[9] = "test category";
        $mysql_querys[9] = "INSERT INTO `cats` VALUES ('','Test Category','1')";

        // MySQL Query: test forum
        $mysql_tnames[10] = "test forum";
        $mysql_querys[10] = "INSERT INTO `forums` VALUES ('','Test Forum','Auto-generated test forum.','1','0','1')";

        $time = time();
        // MySQL Query: test thread
        $mysql_tnames[11] = "test thread";
        $mysql_querys[11] = "INSERT INTO `threads` VALUES ('','Test Thread','1','$time','0','1','0')";

        // MySQL Query: test post
        $mysql_tnames[12] = "test post";
        $mysql_querys[12] = "INSERT INTO `posts` VALUES ('','Test Thread','1','$time','1','1','This is an auto-generated post. It means that SonicBB has been successfully installed! You may delete this post, thread, forum, and/or category.')";

        $ip = @$_SERVER['REMOTE_ADDR'];
        $time = time();
        // MySQL Query: administration login
        $mysql_tnames[13] = "administration login";
        $mysql_querys[13] = "INSERT INTO `users` VALUES ('','$admin_user','$admin_pass','$admin_email','','','','','','','http://','','Default','$ip','Administrator','Administrator','$time')";

        // MySQL Table: guests
        $mysql_tnames[14] = "guests";
        $mysql_querys[14] = "create table `guests` (
       id int(100) auto_increment,
       user varchar(100),
       date int(10),
       primary key(id)
      );";

        // MySQL Table: smileys
        $mysql_tnames[15] = "smileys";
        $mysql_querys[15] = "create table `smileys` (
       id int(100) auto_increment,
       src varchar(255),
       keyVal varchar(5),
       primary key(id)
      );";

        // MySQL Query: smiley 01
        $mysql_tnames[16] = "smiley 01";
        $mysql_querys[16] = "insert into `smileys` values ('','smiley01.gif',':)');";

        // MySQL Query: smiley 02
        $mysql_tnames[17] = "smiley 02";
        $mysql_querys[17] = "insert into `smileys` values ('','smiley02.gif',';)');";

        // MySQL Query: smiley 03
        $mysql_tnames[18] = "smiley 03";
        $mysql_querys[18] = "insert into `smileys` values ('','smiley03.gif',':p');";

        // MySQL Query: smiley 04
        $mysql_tnames[19] = "smiley 04";
        $mysql_querys[19] = "insert into `smileys` values ('','smiley04.gif',':(');";

        // MySQL Query: smiley 05
        $mysql_tnames[20] = "smiley 05";
        $mysql_querys[20] = "insert into `smileys` values ('','smiley05.gif',':d');";

        // MySQL Query: smiley 06
        $mysql_tnames[21] = "smiley 06";
        $mysql_querys[21] = "insert into `smileys` values ('','smiley06.gif',':o');";

        $mysql_php_file_information = "<?" . "php
            define('INSTALLED', true);
         ini_set('display_errors', '0');
         error_reporting(0);
	  \$mysql_user = \"{$mysql_user}\";
      \$mysql_pass = \"{$mysql_pass}\";
      \$mysql_data = \"{$mysql_data}\";
      \$mysql_serv = \"{$mysql_serv}\";

      // DO NOT EDIT BELOW THIS LINE
      mysql_connect(\$mysql_serv, \$mysql_user, \$mysql_pass);
      mysql_select_db(\$mysql_data);
      ?" . ">";

        $error = 0;
        $queryCount = count($mysql_querys);

//      "Opening file includes/mysql.php... ";
        $fp = fopen("$mysqlfilepath", "w");
        if ($fp) {
//         echo "<font color=\"green\">Complete!</font><br /><br />\n";
        }
        else {
         $error = 1;
//         echo "<font color=\"red\">Failed!</font><br /><br />\n";
        }

//      "Writting file includes/mysql.php... ";
        $wr = fwrite($fp, $mysql_php_file_information);
        if ($wr) {
//         echo "<font color=\"green\">Complete!</font><br /><br />\n";
        }
        else {
         $error = true;
        }

//      "Closing file includes/mysql.php... ";
        $fc = @fclose($fp);
        if ($fc) {
//         echo "<font color=\"green\">Complete!</font><br /><br />\n";
        }
        else {
         $error = true;
//         echo "<font color=\"red\">Failed!</font><br /><br />\n";
        }

//        echo "Connecting to MySQL {$mysql_user}:{$mysql_pass}@{$mysql_serv}... ";
        $conn = mysql_connect($mysql_serv, $mysql_user, $mysql_pass);
        if ($conn) {
//         echo "<font color=\"green\">Complete!</font><br /><br />\n";
        }
        else {
         $error = true;
//         echo "<font color=\"red\">Failed!</font><br /><br />\n";
        }

//        echo "Selecting MySQL Database {$mysql_data}... ";
        $db = mysql_select_db($mysql_data);
        if ($db) {
//         echo "<font color=\"green\">Complete!</font><br /><br />\n";
        }
        else {
         $error = true;
        }


        for ($i=0; $i<$queryCount; $i++) {
//       "Executing MySQL Query {$mysql_tnames[$i]}... ";
         $query = mysql_query($mysql_querys[$i]);
         if ($query) {
//          echo "<font color=\"green\">Complete!</font><br /><br />\n";
         }
         else {
         $error = 1;
//          echo "<font color=\"red\">Failed!</font><br /><br />\n";
         }
        }

//        echo "Closing MySQL Database Connection... ";
        $mc = mysql_close($conn);
        if ($mc) {
//         echo "<font color=\"green\">Complete!</font><br /><br />\n";
        }
        else {
         $error = 1;
//         echo "<font color=\"red\">Failed!</font><br /><br />\n";
        }

        if ($error == 1) {
//         echo "There was a problem installing SonicBB. Log the errors above and please go to <a href=\"http://SonicBB.com/forum/index.php\">SonicBB's Support Forum</a> and report these error(s) and we will try to fix these problem(s).\n";
        }
        else {
//         echo "The installation was successful! Please now delete this file.\n";
        }

        //uploading logo

        if($logofilename == ""){
                $logofilename = "logo.jpg";
        }else{
             if (move_uploaded_file( $_FILES['sitelogo']['tmp_name'], $logoimagedest)) {
                 chmod($logoimagedest,0777);
			   list($originalwidth, $originalheight, $originaltype) = getimagesize($logoimagedest);
			   if($originalwidth<=200 and $originalheight<=90){
													  ;
			   }else{
                          $resizedimage=$logoimagedest;
                          if($originalwidth >=200){
                                 $imagewidth=200;
                          }else{
                                 $imagewidth=$originalwidth;
                          }
                          if($originalheight >=90){
                                 $imageheight=90;
                          }else{
                                 $imageheight=$originalheight;
                          }
                          ResizeImageTogivenWitdhAndHeight($logoimagedest.$file_name,$imageheight,$imagewidth,$resizedimage);
               }
             }else{
                  $logofilename = "logo.jpg";
             }
    }
	 $installed = 'true';


/* -------------- /
New code for install tracker, added by girish
/------------------*/
$documentroot	= $_SERVER['DOCUMENT_ROOT'];
$realpath		= realpath("../");
$replacedpath	= str_replace($documentroot,"",$realpath);
$rootserver		= "http://".$_SERVER['SERVER_NAME'].$replacedpath;

$string		= "";
$pro		= urlencode("SonicBB 1.0");
$dom		= urlencode($rootserver);
$ipv		= urlencode($_SERVER['REMOTE_ADDR']);
$mai		= urlencode($admin_email);
$string		= "pro=$pro&dom=$dom&ipv=$ipv&mai=$mai";
$contents	= "no";
$file		= @fopen("http://www.iscripts.com/installtracker.php?$string", 'r');
if ($file) {
	$contents = @fread($file, 8192);
}
/* -------------- /
New code for install tracker, added by girish
/------------------*/




//     header("Location:install_success.php");
//     exit;
  }
}
     $do = "";

/***********Server configuration check ends here*****************/
     //echo "%%%%%%%%%%%%%%%%%%%%%",$installed;
     
?>

<html>
<head>
<title>SonicBB - Installer</title>
<style>
body, table {
 font-size: 12px;
 font-family: Arial, Verdana, Helvetica, Sans-Serif;
}
a {
 color: blue;
}
</style>
<script language="javascript1.1" type="text/javascript" src="../images/bubble-tooltip.js"></script>
<link rel="stylesheet" href="../images/bubble-tooltip.css" type="text/css" media="screen">
</head>
<body bgcolor="#40587b" topmargin="0">
<?php

if ($do == "") {
        $mysql_user = @$_GET['mysql_user'] ? @$_GET['mysql_user'] : "root";
        $mysql_pass = @$_GET['mysql_pass'];
        $mysql_data = @$_GET['mysql_data'] ? @$_GET['mysql_data'] : "SonicBB";
        $mysql_serv = @$_GET['mysql_serv'] ? @$_GET['mysql_serv'] : "localhost";
        $sitename   = @$_GET['sitename'];
        $admin_email = @$_GET['admin_email'];
        $admin_user = @$_GET['admin_user'];
        $admin_pass = @$_GET['admin_pass'];

?>
<form method="post" action="install.php" enctype="multipart/form-data">
 <input type="hidden" name="do" value="finish">
 <table width=777 border=0 align=center bgcolor="#edeff1">
  <tr>
    <td colspan=4>
   <?php  
    if ($installed=='true') { 
	
   ?>
    <table width=750 border=0 align=center bgcolor=#edeff1 height=450>
        <tr>
                <td align=center class="maintext" >
                <b><font size="+1">Congratulations! The Installation Process is completed successfully!</font></b>
                </td>
        </tr>
        <tr>
                <td align=center class="maintext" >
                <div>
                <br><br>
                </div>
                <b>To ensure complete security, now you should remove the <font color="#FF0000">'install'</font> directory.</b>
                <div>
                <br>
                </div>
                <a class=anchor href="../index.php">Home</a>
                </td>
        </tr>
        <tr><td  colspan="4">&nbsp;</td></tr>
    </table>
  <?php 
   }else{
       
    ?>

    <table width=750 border=0 align=center bgcolor=#edeff1>
	 <tr>
	  <td align=right><a class="listing" title="OnlineInstallationManual" href="#" onClick="window.open('<?php echo htmlentities($txtSiteURL);?>/docs/sonicbb.pdf','OnlineInstallationManual','top=100,left=100,width=820,height=550,scrollbars=yes,toolbar=no,status=yrd');"><strong>Installation manual</strong></a> | <a class="listing" title="Readme" href="#" onClick="window.open('<?php echo htmlentities($txtSiteURL);?>/Readme.txt','Readme','top=100,left=100,width=820,height=550,scrollbars=yes,toolbar=no,status=yrd');"><strong>Readme</strong></a></td>
	 </tr>
	 <tr>
	  <td align=right>
		<a class="listing" title="If you have any difficulty, submit a ticket to the support department" href="#" onClick="window.open('http://www.iscripts.com/support/postticketbeforeregister.php','','top=100,left=100,width=820,height=550,scrollbars=yes,toolbar=no,status=yrd,resizable=yes');">														
		<strong>Get Support</strong></a></td>
	 </tr>
     <tr>
       <td colspan=4>
            <div align="justify">
            <br>
                    Thank you for choosing SonicBB. <br><br>
                    In order to complete this install please fill out the details requested below. <br>Please note the following points before you continue:<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;1.Change the permission (chmod 777 for linux server) of 'includes/mysql.php'.<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;2.Change the permission (chmod 777 for linux server) of 'images' folder. (After installation dont forget to change it back to 755)<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;3.Change the permission (chmod 777 for linux server) of 'images/smileys' folder. (After installation dont forget to change it back to 755)<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;4. The database you install into should already exist.<br>
                    &nbsp;&nbsp;&nbsp;&nbsp;5. After the install process delete the 'install' directory.
            <br><br>
            </div>
       </td>
     </tr>
    </table>
    <table width=750 border=0 align=center bgcolor=#edeff1>
       <tr>
           <td align=center>
             <div align="left">
                <font color="#FF0000">
                  <?=$message;  ?>
                </font>
             </div>
           </td>
       </tr>
       <tr><td  colspan="4">&nbsp;</td></tr>
    </table>
     <FIELDSET>
        <LEGEND class="maintext">MySQL Database Information</LEGEND>
          <table  width=100% border=0 align=center bgcolor=#FFFFFF>
            <tr><td  colspan="4">&nbsp;</td></tr>
            <tr>
             <td width=123>&nbsp;</td>
             <td align="right"><b>MySQL Username:</b></td>
             <td width="484"><input type="text" name="mysql_user" value="<?php echo $mysql_user; ?>"></td>
            </tr>
            <tr>
             <td width=123>&nbsp;</td>
             <td align="right" width=150><b>MySQL Password:</b></td>
             <td><input type="password" name="mysql_pass" value="<?php echo $mysql_pass; ?>"></td>
            </tr>
            <tr>
             <td width=123>&nbsp;</td>
             <td align="right" width=150><b>MySQL Database:</b></td>
             <td><input type="text" name="mysql_data" value="<?php echo $mysql_data; ?>"></td>
            </tr>
            <tr>
             <td width=123>&nbsp;</td>
             <td align="right" width=150><b>MySQL Server:</b></td>
             <td><input type="text" name="mysql_serv" value="<?php echo $mysql_serv; ?>"></td>
            </tr>
            <tr><td  colspan="4">&nbsp;</td></tr>
         </table>
       </fieldset>
     <FIELDSET>
        <LEGEND class="maintext">Forum Information</LEGEND>
          <table  width=100% border=0 align=center bgcolor=#FFFFFF>
            <tr><td  colspan="4">&nbsp;</td></tr>
            <tr>
             <td width=122>&nbsp;</td>
             <td align="right" width=158><b>License Key:</b></td>
             <td width="240"><input name="txtLicenseKey"  id="txtLicenseKey" type="text" class="textbox" size="40" maxlength="40" value="<?php echo htmlentities($txtLicenseKey);?>" onFocus="showToolTip(event,'The script would function only for the domain it is licensed. If you cannot recall the license, its also included in the email you received with subject: \'iScripts.com software download link\'. You can also get the license key from your user panel at www.iscripts.com','licensekey','txtLicenseKey');" onBlur="hideToolTip('licensekey')"></td>
			<td width="233" class="maintext">
				<div id="bubble_tooltiplicensekey">
					<div class="bubble_top"><span>&nbsp;</span></div>
					<div class="bubble_middle"><span id="bubble_tooltip_contentlicensekey">&nbsp;</span></div>
					<div class="bubble_bottom"></div>
				</div>
			</td>
            </tr>
            <tr>
             <td width=122>&nbsp;</td>
             <td align="right" width=158><b>Sitename:</b></td>
             <td colspan="2"><input type="text" name="sitename" value="<?php echo $sitename; ?>"></td>
            </tr>
            <tr>
             <td width=122>&nbsp;</td>
             <td align="right" width=158><b>Administrator's E-mail:</b></td>
             <td colspan="2"><input type="text" name="admin_email" value="<?php echo $admin_email; ?>"></td>
            </tr>
            <tr>
             <td width=122>&nbsp;</td>
             <td align="right" width=158><b>Sitelogo:</b></td>
             <td colspan="2"><input type="file" name="sitelogo" id="sitelogo" ></td>
            </tr>
            <tr><td  colspan="4">&nbsp;</td></tr>
         </table>
        </fieldset>
     <FIELDSET>
        <LEGEND class="maintext">Administrator Login</LEGEND>
          <table  width=100% border=0 align=center bgcolor=#FFFFFF>
            <tr><td colspan="4">&nbsp;</td></tr>
            <tr>
             <td width=120>&nbsp;</td>
             <td align="right" width=159><b>Username:</b></td>
             <td width="173"><input type="text" name="admin_user" value="<?php echo $admin_user; ?>"></td>
             <td width="301">Valid characters are a-z,A-Z,0-9, and _ (underscore).</td>
            </tr>
            <tr>
             <td width=120>&nbsp;</td>
             <td align="right" width=159><b>Password:</b></td>
             <td><input type="password" name="admin_pass" value="<?php echo $admin_pass; ?>"></td>
             <td>Valid characters are a-z,A-Z,0-9, and _ (underscore).</td>
            </tr>
            <tr><td  colspan="4">&nbsp;</td></tr>
         </table>
      </fieldset>
          <table width=100% border=0 align=center bgcolor=#FFFFFF>
            <tr><td colspan=4>&nbsp;</td></tr>
            <tr>
             <td width=50>&nbsp;</td>
             <td align="center" colspan="2">
              <input type="submit" value="Install">
             </td>
            </tr>
           <tr><td  colspan="4">&nbsp;</td></tr>
        </table>
     <?php  }
     ?>
	 </td>
</tr>
<tr><td align="center">Powered by <a href="http://www.iscripts.com/sonicbb/" target="_blank">iScripts SonicBB</a>. A premium product from <a href="http://www.iscripts.com/" target="_blank">iScripts.com</a></td>
</tr>
</table>
</form>

<?php
}
?>

</body>
</html>