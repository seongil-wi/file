<?php
$configfile = "../includes/mysql.php";
$configcontents = @fread(@fopen($configfile, 'r'), @filesize($configfile));
$pos = strpos($configcontents,"INSTALLED");
if($pos === false){
	header("Location:install.php");
}else{
	header("Location:../index.php");
}

?>


