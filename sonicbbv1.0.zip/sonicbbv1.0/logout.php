<?php
require("includes/global.php");

if ($userInfo['loggedin']) {
 mysql_query("DELETE FROM `online` WHERE username='".$userInfo['username']."'");
 $_SESSION['user'] = null;
 $_SESSION['loggedin'] = 0;
 session_unset();
}

header("Location: index.php");
?>