<?php
require("includes/global.php");

$id = @$_GET['id'];

if ($id) {
 $query = mysql_query("SELECT * FROM `users` WHERE id='$id'");
 $q = mysql_fetch_array($query);
 if (!$q) {
  header("Location: index.php");
 }
 $pageInfo['title'] = "View Profile: ".$q['username'];
 $pageInfo['homelink'] .= " -> <a href=\"members.php?id={$id}\">View Profile</a>";
 fetchTemplate("header");
 fetchTemplate("profile");
 fetchTemplate("footer");
}
else {
 $pageInfo['title'] = "Members List";
 $pageInfo['homelink'] .= " -> <a href=\"members.php\">Members List</a>";
 fetchTemplate("header");

 $maxPerPage = $pageInfo['maxPerPage'];
 $p = @$_GET['p'] ? @$_GET['p'] : 1;
 $offset = ($p * $maxPerPage) - $maxPerPage;

 $oldquery = mysql_query("SELECT * FROM `users`");
 $oldcount = mysql_num_rows($oldquery);

 $pagecount = ceil($oldcount / $maxPerPage);
 echo "Page: ";
 if ($p > 1) {
  $prev = $p - 1;
  echo "<a href=\"?p={$prev}\">Previous</a>&nbsp;\n";
 }
 for ($i=0; $i<$pagecount; $i++) {
  if (($i+1) == $p) {
   echo "<b>{$p}</b>&nbsp;\n";
  }
  else {
   echo "<a href=\"?p=" . ($i+1) . "\">" . ($i+1) . "</a>&nbsp;\n";
  }
 }
 if ($p < $pagecount) {
  $prev = $p + 1;
  echo "<a href=\"?p={$prev}\">Next</a>&nbsp;\n";
 }
 echo "<br />\n";

 $query = mysql_query("SELECT * FROM `users` ORDER BY id ASC LIMIT $offset,$maxPerPage");
 fetchTemplate("memberstop");
 while ($q = mysql_fetch_array($query)) {
  fetchTemplate("memberlist");
 }
 fetchTemplate("membersend");

 $pagecount = ceil($oldcount / $maxPerPage);
 echo "Page: ";
 if ($p > 1) {
  $prev = $p - 1;
  echo "<a href=\"?p={$prev}\">Previous</a>&nbsp;\n";
 }
 for ($i=0; $i<$pagecount; $i++) {
  if (($i+1) == $p) {
   echo "<b>{$p}</b>&nbsp;\n";
  }
  else {
   echo "<a href=\"?p=" . ($i+1) . "\">" . ($i+1) . "</a>&nbsp;\n";
  }
 }
 if ($p < $pagecount) {
  $prev = $p + 1;
  echo "<a href=\"?p={$prev}\">Next</a>&nbsp;\n";
 }
 echo "<br /><br />\n";

 fetchTemplate("footer");
}
?>