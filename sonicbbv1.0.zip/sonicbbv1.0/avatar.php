<?php
include("includes/global.php");

$avat = @$_GET['avat'];
$file = $avat;

if (preg_match("/^.*\.gif/",$file)) $type = "gif";
else if (preg_match("/^.*\.jpg/",$file)) $type = "jpg";
else if (preg_match("/^.*\.png/",$file)) $type = "png";
else {
 header("Content-type: image/gif");
 $im = imagecreatefromgif("templates/".$pageInfo['theme']."/images/noavatar.gif");
 imagegif($im);
 imagedestroy($im);
 exit;
}

header("Content-type: image/{$type}");

if ($type == "gif") {
 $im = imagecreatefromgif($file);
 imagegif($im);
}
else if ($type == "jpg") {
 $im = imagecreatefromjpeg($file);
 imagejpeg($im);
}
else if ($type == "png") {
 $im = imagecreatefrompng($file);
 imagepng($im);
}

imagedestroy($im);
?>