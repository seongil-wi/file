<html>
<head>
<title>FutureBB 1.1 to 1.2 Update Patch</title>
<style>
body, table {
 font-size: 12px;
 font-family: Arial;
}
</style>
</head>
<body>
<?php
$do = @$_POST['do'];

if ($do == "") {
?>
<center><font size="+1">FutureBB 1.1 to 1.2 Update Patch</font></center><br />
Before running this file, make sure you have overwritten all of your old 1.1 files with the new 1.2 files. You will need to provide your MySQL username, password, server, and database from your old 1.1 installation - since the old configuration file has been overwritten.<br /><br />
<form method="POST" action="?">
 <input type="hidden" name="do" value="update">
 <table>
  <tr>
   <td align="right"><b>MySQL Username:</b></td>
   <td><input type="text" name="mysql_user" value="root" size="15"></td>
  </tr>
  <tr>
   <td align="right"><b>MySQL Password:</b></td>
   <td><input type="password" name="mysql_pass" size="15"></td>
  </tr>
  <tr>
   <td align="right"><b>MySQL Database:</b></td>
   <td><input type="text" name="mysql_data" value="futurebb" size="15"></td>
  </tr>
  <tr>
   <td align="right"><b>MySQL Server:</b></td>
   <td><input type="text" name="mysql_serv" value="localhost" size="15"></td>
  </tr>
  <tr>
   <td align="center" colspan="2"><input type="submit" value="UPDATE"></td>
  </tr>
 </table>
</form>
<?php
}
else if ($do == "update") {
 $mysql_user = addslashes(@$_POST['mysql_user']);
 $mysql_pass = addslashes(@$_POST['mysql_pass']);
 $mysql_data = addslashes(@$_POST['mysql_data']);
 $mysql_serv = addslashes(@$_POST['mysql_serv']);
 if ($mysql_user && $mysql_data && $mysql_serv) {
  $mysql_php_file_information = "<?" . "php
\$mysql_user = \"{$mysql_user}\";
\$mysql_pass = \"{$mysql_pass}\";
\$mysql_data = \"{$mysql_data}\";
\$mysql_serv = \"{$mysql_serv}\";

// DO NOT EDIT BELOW THIS LINE
mysql_connect(\$mysql_serv, \$mysql_user, \$mysql_pass);
mysql_select_db(\$mysql_data);
?" . ">";

  $error = 0;
  $fp = @fopen("includes/mysql.php", "w");
  if ($fp) {
   $wr = @fwrite($fp, $mysql_php_file_information);
   if (!$wr) {
    $error = 1;
    echo "Unable to write to includes/mysql.php file.";
   }
  }
  else {
   $error = 1;
   echo "Failed to open includes/mysql.php file.";
  }
  @fclose($fp);

  if (!$error) {
   include("includes/mysql.php");
   $q1 = mysql_query("ALTER TABLE `users` ADD subtitle varchar(255) AFTER title");
   $q2 = mysql_query("UPDATE `users` SET subtitle=title");
   $q3 = mysql_query("ALTER TABLE `cats` ADD catOrder int(100) AFTER name");
   $c = 1;
   $q = mysql_query("SELECT * FROM `cats`");
   while ($row = mysql_fetch_array($q)) {
    mysql_query("UPDATE `cats` SET catOrder='$c' WHERE id='{$row['id']}'");
    $c++;
   }
   $q4 = mysql_query("ALTER TABLE `forums` ADD forumOrder int(100) AFTER locked");
   $c = 1;
   $q = mysql_query("SELECT * FROM `forums`");
   while ($row = mysql_fetch_array($q)) {
    mysql_query("UPDATE `forums` SET forumOrder='$c' WHERE id='{$row['id']}'");
    $c++;
   }
   $q5 = mysql_query("create table `guests` (
 id int(100) auto_increment,
 user varchar(100),
 date int(10),
 primary key(id)
);");
   $q6 = mysql_query("create table `smileys` (
 id int(100) auto_increment,
 src varchar(255),
 keyVal varchar(5),
 primary key(id)
);");
   $q7 = mysql_query("insert into `smileys` values ('','smiley01.gif',':)');");
   $q8 = mysql_query("insert into `smileys` values ('','smiley02.gif',';)');");
   $q9 = mysql_query("insert into `smileys` values ('','smiley03.gif',':p');");
   $q10 = mysql_query("insert into `smileys` values ('','smiley04.gif',':(');");
   $q11 = mysql_query("insert into `smileys` values ('','smiley05.gif',':d');");
   $q12 = mysql_query("insert into `smileys` values ('','smiley06.gif',':o');");
   $q13 = mysql_query("ALTER TABLE `threads` ADD sticky int(1) AFTER inForum");
   $q14 = mysql_query("UPDATE `threads` SET sticky='0'");
   echo "Your FutureBB 1.1 installation has now been upgraded to FutureBB 1.2!<br />";
   echo "You should delete this file now.";
  }
 }
 else {
  echo "You need to specify a username, database, and host name.";
 }
 echo "<br /><br />\n<a href=\"update.php\">[ Back ]</a>\n";
}
?>
</body>
</html>