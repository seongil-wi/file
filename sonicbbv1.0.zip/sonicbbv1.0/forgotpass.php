<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */
// +----------------------------------------------------------------------+
// | PHP version 4/5                                                      |
// +----------------------------------------------------------------------+
// | Copyright (c) 2005-2006 ARMIA INC                                    |
// +----------------------------------------------------------------------+
// | This source file is a part of sonicbb                                |
// +----------------------------------------------------------------------+
// | Authors: roshith<roshith@armia.com>                                  |
// |                                                                                                            |
// +----------------------------------------------------------------------+


include("includes/global.php");
//global $pageInfo;

$pageInfo['title'] = "Forgot Password";

$redir = @$_GET['redir'];
if (!$redir) $redir = "index.php";

if (!$userInfo['loggedin']) {
 $do = @$_GET['do'];
 if ($do == "") {
  fetchTemplate("header");
  fetchTemplate("forgotpass");
  fetchTemplate("footer");
 }
 else if ($do == "forgotpass") {
  $error = "";
  $email = addslashes(htmlentities(@$_POST['email']));

  if($email !=""){
    $query = mysql_query("SELECT * FROM `users` WHERE email='$email' AND title!='Administrator'");
    $q = mysql_fetch_row($query);

    if (!$q[0]) {
         $error .= "Email does not exist.";
    }
    else {
    // sending password to the user

         $userid   = $q[0];     //  id
         $username = $q[1];     //  username
         $fname    = $q[4];     //  fname
         $lname    = $q[5];     //  lname

         $userfullname  = trim($fname . " ". $lname);

         $randnum1 = mt_rand();
         if(strlen($randnum1) > 6){
            $randnum1 = substr($randnum1,0,6);
         }
         $pass = md5($randnum1);

         $sqlreset = "UPDATE users SET password = '$pass' WHERE id = '$userid' ";

         $mailcontent = "Dear $email,\n";
         $mailcontent .= "Your ".stripslashes($pageInfo['sitename'])." password has been reset on request.\n";
         $mailcontent .= "The following are your new login details.\n\n";
         $mailcontent .= "User Name: \t".$username ."\n" ;
         $mailcontent .= "Password: \t".$randnum1 ."\n\n" ;
         $mailcontent .= "Regards,\nAdministrator" ;
         $subject = "Password reset at ".stripslashes($pageInfo['sitename']);
         $headers = "From: ".stripslashes($pageInfo['sitename'])."<".$pageInfo['adminEmail'].">\r\n";

         $mailsent = mail($email,$subject,$mailcontent,$headers);
//		 $mailsent=1;

         if($mailsent){
              mysql_query($sqlreset);
			  $msg = "Your password has been sent successfully.";
//              $msg = "In The Demo Can't Send New Password";
         }else{
	  		  $error .= "Can not send mail.";
         }
    }
  }else
     $error .= "Please Enter Your Email.";
  if ($error || $msg) {
      fetchTemplate("header");
      echo "<br><p align=center><font color=red>".$error."</font></p>";
      echo "<br><p align=center><font color=red>".$msg."</font></p>";

      echo "<p align=center><a href=\"forgotpass.php\">[ Back ]</a></p>\n";
      fetchTemplate("footer");
  }
 }
}
else {
 header("Location: index.php");
}
?>