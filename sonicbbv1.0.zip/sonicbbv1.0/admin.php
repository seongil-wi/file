<?php
include("includes/global.php");

$pageInfo['title'] = "Admin CP";
$pageInfo['homelink'] .= " -> <a href=\"admin.php\">Admin CP</a>";

if (@$userInfo['title'] != "Administrator") {
 fetchTemplate("header");
 fetchTemplate("noaccess");
 fetchTemplate("footer");
 die();
}

fetchTemplate("header");

$do = @$_GET['do'];
if ($do == "") {
 $page = "admin/main";
 fetchTemplate("admin/home");
}
else if ($do == "banip") {
 $bdo = @$_GET['bdo'];
 if ($bdo == "") {
  $page = "admin/banip";
 }
 else if ($bdo == "add") {
  $page = "admin/banipadd";
 }
 else if ($bdo == "unban") {
  $page = "admin/banipunban";
 }
 fetchTemplate("admin/home");
}
else if ($do == "deluser") {
 $bdo = @$_POST['bdo'];
 if ($bdo == "") {
  $page = "admin/deluser";
 }
 else if ($bdo == "del") {
  $page = "admin/delusernow";
 }
 fetchTemplate("admin/home");
}
else if ($do == "frmhd") {
 $bdo = @$_POST['bdo'];
 if ($bdo == "") {
  $page = "admin/homedata";
 }
 else if ($bdo == "update") {
  $page = "admin/dataupd";
 }
 fetchTemplate("admin/home");
}
else if ($do == "frmmg") {
 $bdo = @$_GET['bdo'];
 if ($bdo == "") {
  $page = "admin/frmang";
 }
 else if ($bdo == "rencat") {
  $page = "admin/rencat";
 }
 else if ($bdo == "delcat") {
  $page = "admin/delcat";
 }
 else if ($bdo == "edtfrm") {
  $page = "admin/edtfrm";
 }
 else if ($bdo == "delfrm") {
  $page = "admin/delfrm";
 }
 else if ($bdo == "newcat") {
  $page = "admin/newcat";
 }
 else if ($bdo == "newfrm") {
  $page = "admin/newfrm";
 }
 else if ($bdo == "movecat") {
  $page = "admin/movecat";
 }
 else if ($bdo == "movefrm") {
  $page = "admin/moveforum";
 }
 fetchTemplate("admin/home");
}
else if ($do == "setrank") {
 $bdo = @$_GET['bdo'];
 $page = "admin/setrank";
 fetchTemplate("admin/home");
}
else if ($do == "usertitle") {
 $bdo = @$_GET['bdo'];
 $page = "admin/setutitle";
 fetchTemplate("admin/home");
}
else if ($do == "smileys") {
 $bdo = @$_GET['bdo'];
 $page = "admin/smileys";
 fetchTemplate("admin/home");
}

fetchTemplate("footer");
?>