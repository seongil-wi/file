<?php
require("includes/global.php");

$pageInfo['title'] = "User CP";
$pageInfo['homelink'] .= " -> <a href=\"usercp.php\">User CP</a>";

// date("l, F j, Y g:ia", $userInfo['reggedOn'])

if (!$userInfo['loggedin']) {
 header("Location: login.php?redir=usercp.php");
}

$do = @$_GET['do'];
if ($do == "") {
 $page = "
From here you may change your profile information, avatar, signature, e-mail, password, etc.
 ";
 fetchTemplate("header");
 fetchTemplate("usercphome");
 fetchTemplate("footer");
}
else if ($do == "Change Profile") {
 $avat = $userInfo['defaultAvatar'] ? "http://" : $userInfo['avatar'];
 $page = '
<form method="post" action="usercp.php?do=chp">
 <fieldset>
  <legend>Change Password (optional)</legend>
  <table style="color: black">
   <tr>
    <td align="right">Old Password:</td>
    <td><input type="password" name="oldpass" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right">New Password:</td>
    <td><input type="password" name="newpass" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right">Repeat Password:</td>
    <td><input type="password" name="reppass" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="center" colspan="2"><input type="submit" value="Update"></td>
   </tr>
  </table>
 </fieldset>
</form>

<form method="post" action="usercp.php?do=chinfo">
 <fieldset>
  <legend>Personal Information (optional)</legend>
  <table style="color: black">
   <tr>
    <td align="right"><b>Firstname:</b></td>
    <td><input type="text" name="fname" value="'.$userInfo['fname'].'" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right"><b>Lastname:</b></td>
    <td><input type="text" name="lname" value="'.$userInfo['lname'].'" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="center" colspan="2"><input type="submit" value="Update"></td>
   </tr>
  </table>
 </fieldset>
</form>

<form method="post" action="usercp.php?do=chm">
 <fieldset>
  <legend>Messengers (optional)</legend>
  <table style="color: black">
   <tr>
    <td align="right"><b>AIM:</b></td>
    <td><input type="text" name="aim" value="'.$userInfo['aim'].'" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right"><b>MSN:</b></td>
    <td><input type="text" name="msn" value="'.$userInfo['msn'].'" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right"><b>YIM:</b></td>
    <td><input type="text" name="yim" value="'.$userInfo['yim'].'" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right"><b>ICQ:</b></td>
    <td><input type="text" name="icq" value="'.$userInfo['icq'].'" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="center" colspan="2"><input type="submit" value="Update"></td>
   </tr>
  </table>
 </fieldset>
</form>

<form method="post" action="usercp.php?do=chminfo">
 <fieldset>
  <legend>Member Info (optional)</legend>
  <table style="color: black">
   <tr>
    <td align="right"><b>Avatar URL:</b></td>
    <td><input type="text" name="avat" value="'.$avat.'" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right" valign="top"><b>Sig:</b></td>
    <td><textarea rows="5" cols="50" name="sig">'.$userInfo['sig'].'</textarea></td>
   </tr>
   <tr>
    <td align="center" colspan="2"><input type="submit" value="Update"></td>
   </tr>
  </table>
 </fieldset>
</form>
';
 $pageInfo['homelink'] .= " -> <a href=\"usercp.php?do=Change Profile\">Change Profile</a>";
 fetchTemplate("header");
 fetchTemplate("usercphome");
 fetchTemplate("footer");
}
else if($do == "chp") {
 $pageInfo['homelink'] .= " -> <a href=\"usercp.php?do=chp\">Change Password</a>";

 $oldpass = @$_POST['oldpass'];
 $newpass = @$_POST['newpass'];
 $reppass = @$_POST['reppass'];
 if (!$oldpass || !$newpass || !$reppass) {
  header("Location: usercp.php?do=Change Profile");
 }
 else if (md5($oldpass) != $userInfo['password']) {
  fetchTemplate("header");
?>
<p align=center><font color=red>Old password is not your current password. Please enter your correct, current (old) password.<br /></font></p>
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
  fetchTemplate("footer");
 }
 else if ($newpass != $reppass) {
  fetchTemplate("header");
?>
<p align=center><font color=red>New password is not the same as repeat password. You must enter the same password in both new and repeat password boxes.<br /></font></p>
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
  fetchTemplate("footer");
 }
 else {
  $newpass = md5($newpass);
  $query = mysql_query("UPDATE `users` SET password='$newpass' WHERE id='".$userInfo['id']."'");
  if ($query) {
   fetchTemplate("header");
?>
<p align=center><font color=red>Your password has been changed!<br /><br />
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
   fetchTemplate("footer");
  }
  else {
   fetchTemplate("header");
?>
<p align=center><font color=red>Unable to change password. Please try again later.<br /></font></p>
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
   fetchTemplate("footer");
  }
 }
}
else if ($do == "chinfo") {
 $fname = addslashes(@$_POST['fname']);
 $lname = addslashes(@$_POST['lname']);
 $q = mysql_query("UPDATE `users` SET fname='$fname', lname='$lname' WHERE id='".$userInfo['id']."'");
 fetchTemplate("header");
 if ($q) {
?>
<p align=center><font color=red>Your profile information has been changed!<br /></font></p>
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
 }
 else {
?>
<p align=center><font color=red>Unable to change profile information. Please try again later.<br /></font></p>
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
 }
 fetchTemplate("footer");
}
else if ($do == "chm") {
 $aim = addslashes(@$_POST['aim']);
 $msn = addslashes(@$_POST['msn']);
 $yim = addslashes(@$_POST['yim']);
 $icq = addslashes(@$_POST['icq']);
 $q = mysql_query("UPDATE `users` SET aim='$aim', msn='$msn', yim='$yim', icq='$icq' WHERE id='".$userInfo['id']."'");
 fetchTemplate("header");
 if ($q) {
?>
<p align=center><font color=red>Your profile information has been changed!<br /></font></p>
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
 }
 else {
?>
<p align=center><font color=red>Unable to change profile information. Please try again later.<br /></font></p>
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
 }
 fetchTemplate("footer");
}
else if ($do == "chminfo") {
 $avat = addslashes(@$_POST['avat']);
 $sig = addslashes(@$_POST['sig']);
 $q = mysql_query("UPDATE `users` SET avatar='$avat', sig='$sig' WHERE id='".$userInfo['id']."'");
 fetchTemplate("header");
 if ($q) {
?>
<p align=center><font color=red>Your profile information has been changed!<br /></font></p>
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
 }
 else {
?>
<p align=center><font color=red>Unable to change profile information. Please try again later.<br /></font></p>
<p align=center><a href="usercp.php?do=Change Profile">[ Back ]</a><br /></p>
<?php
 }
 fetchTemplate("footer");
}
else if ($do == "theme") {
 $theme = @$_POST['theme'];
 if ($theme == 0 || ($theme && is_dir("templates/".$theme))) {
  mysql_query("UPDATE `users` SET theme='$theme' WHERE id='".$userInfo['id']."'");
  header("Location: index.php");
 }
 else {
  header("Location: index.php");
 }
}
?>