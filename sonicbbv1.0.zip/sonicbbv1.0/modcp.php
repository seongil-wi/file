<?php
include("includes/global.php");

$pageInfo['title'] = "Mod CP";
$forum = @$_GET['forum'];
$do = @$_GET['do'];
$id = @$_GET['id'];

if ($forum == "" || $do == "" || $id == "") {
 header("Location: index.php");
}

$q = mysql_query("SELECT * FROM `threads` WHERE id='$id'");
$q = mysql_fetch_array($q);

if ($userInfo['loggedin'] && $q && ($userInfo['title'] == "Moderator" || $userInfo['title'] == "Administrator")) {
 if ($do == "sticky") {
  $q = mysql_query("UPDATE `threads` SET sticky='1' WHERE id='$id'");
  if ($q) {
   header("Location: viewforum.php?id={$forum}");
  }
  else {
   fetchTemplate("header");
   echo "<font color=red>Unable to set sticky. Please try again later.</font>";
   echo "<br />\n<a href=\"viewforum.php?id={$forum}\">[ Back ]</a>\n";
   fetchTemplate("footer");
  }
 }
 else if ($do == "del") {
  $q = mysql_query("DELETE FROM `posts` WHERE inThread='$id'");
  $q2 = mysql_query("DELETE FROM `threads` WHERE id='$id'");
  if ($q && $q2) {
   header("Location: viewforum.php?id={$forum}");
  }
  else {
   fetchTemplate("header");
   echo "<font color=red>Unable to delete thread. Please try again later.</font>";
   echo "<br />\n<a href=\"viewforum.php?id={$forum}\">[ Back ]</a>\n";
   fetchTemplate("footer");
  }
 }
}
else {
 fetchTemplate("header");
 fetchTemplate("noaccess");
 fetchTemplate("footer");
}
?>