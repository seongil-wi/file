<?php
// +----------------------------------------------------------------------+
// | PHP version 4/5                                                      |
// +----------------------------------------------------------------------+
// | Copyright (c) 2005-2006 ARMIA INC                                    |
// +----------------------------------------------------------------------+
// | This source file is a part of sonicBB                                |
// +----------------------------------------------------------------------+
// | Authors: roshith<roshith@armia.com>                          		  |
// +----------------------------------------------------------------------+
require("includes/global.php");

$pageInfo['title'] = "Invalid License";

fetchTemplate("invalidheader");

//fetchTemplate("catrow");

//fetchTemplate("endcat");

fetchTemplate("invalidfooter");
?>