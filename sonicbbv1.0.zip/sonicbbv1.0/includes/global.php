<?php
$configfile = "./includes/mysql.php";
$configcontents = @fread(@fopen($configfile, 'r'), @filesize($configfile));
//echo"content",$configcontents;
//exit;
$pos = strpos($configcontents, "INSTALLED");

if ($pos === false) { header("Location:./install/index.php");;
} else { ;
//    header("Location:./index.php");
}
session_start();
include("mysql.php");

$startTime = time();

define("THEME_ID", 0);
define("SBB_VERSION", 1.01);
$inforum = true;

$query = mysql_query("SELECT * FROM `data`");
$q = mysql_fetch_array($query);

// page information
$pageInfo = $q;
$pageInfo['theme'] = $q['defaultTheme'];
$pageInfo['sitename'] = stripslashes($pageInfo['sitename']);
$pageInfo['homelink'] = "<a href=\"index.php\">".$pageInfo['sitename']."</a>";
$pageInfo['maxPerPage'] = 10;


// user information
$userInfo = array();
if (@$_SESSION['loggedin']) {
	 $u = @$_SESSION['user'];
	 $query = mysql_query("SELECT * FROM `users` WHERE username='$u'");
	 $q = mysql_fetch_array($query);
	 $userInfo = $q;
	 $userInfo['loggedin'] = 1;
	 $q = mysql_query("SELECT * FROM `posts` WHERE posterId='{$userInfo['id']}'");
	 $q = mysql_num_rows($q);
	 $userInfo['posts'] = $q;

	 $userInfo['defaultAvatar'] = false;
	 $file = $userInfo['avatar'];
	 if (!preg_match("/^.*\.gif/",$file)) {
		  if (!preg_match("/^.*\.jpg/",$file)) {
			   if (!preg_match("/^.*\.png/",$file)) {
				    $userInfo['avatar'] = "templates/{$pageInfo['theme']}/images/noavatar.gif";
				    $userInfo['defaultAvatar'] = true;
			   }
		  }
	 }
}
else $userInfo['loggedin'] = 0;

if ($userInfo['loggedin']) {
	 if ($userInfo['theme'] == "0") { 
		  $userInfo['useDefault'] = true;
	 }
	 else {
		  $userInfo['useDefault'] = false; 
		  if (is_dir("templates/".$userInfo['theme'])) {
			   $pageInfo['theme'] = $userInfo['theme']; 
		  }
	 }
}

function fetchTemplate($name) {
 global $pageInfo;
 if (file_exists("templates/".$pageInfo['theme']."/".$name.".php")) {
 	  require("templates/".$pageInfo['theme']."/".$name.".php");
 }
 else {
	  echo "<b>Warning:</b> Unable to find ".$name." file.<br />\n";
 }
}

function preg_chars($pat, $str) {
 $error = 0;
 for ($i=0; $i<strlen($str); $i++) {
  //if (!ereg($pat, $str[$i])) {
  if (!preg_match($pat, $str[$i])) {   
   $error = 1;
   $i = strlen($str);
  }
 }
 return $error;
}

function showSmileys() {
 $query = mysql_query("SELECT * FROM `smileys`");
 while ($row = mysql_fetch_array($query)) {
  echo "<a onClick=\"JavaScript: insertSmiley('{$row['keyVal']}')\"><img src=\"images/smileys/{$row['src']}\" alt=\"{row['keyVal']}\" title=\"{$row['keyVal']}\"></a>\n";
 }
}

function format_chars($str) {
 $str = preg_replace("/\//", "&#47", $str);
 $str = preg_replace("/\\\\/", "&#92", $str);
 $str = preg_replace("/\"/", "&#34", $str);
 $str = preg_replace("/'/", "&#39", $str);
 return $str;
}

/////added by roshith on 9-8-06

function isValidEmail($email) {
        //if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)) {
        //if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i", $email)) {
    

if (!preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/',$email)){
                return false;
        }
        return true;
}

/////////
// banned IP addresses
$myip = $_SERVER['REMOTE_ADDR'];
$q = mysql_query("SELECT * FROM `bannedips`");
while ($row = mysql_fetch_array($q)) {
 if ($myip == $row['ip']) {
  $pageInfo['title'] = "Banned";
  $pageInfo['homelink'] .= " -> <b>BANNED</b>";
  fetchTemplate("header");
  fetchTemplate("banned");
  fetchTemplate("footer");
  die();
 }
}
function getLicense(){
	global $pageInfo;
	$var_licencekey = stripslashes($pageInfo["vLicenceKey"]);
	return $var_licencekey;
}
?>