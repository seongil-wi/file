<?php
global $inforum;
if ($inforum != true) {
 header("Location: ../../index.php");
}
?>