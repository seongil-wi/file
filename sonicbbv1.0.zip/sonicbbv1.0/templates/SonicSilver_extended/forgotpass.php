<?php
include("_confirm.php");

global $userInfo, $redir;
if ($userInfo['loggedin']) {
 header("Location: index.php");
}
else if (@$_GET['do'] == "login") {

}
else { ?>
<form method="post" action="forgotpass.php?do=forgotpass&redir=<?php echo $redir; ?>">
 <table align="center" width=300>
  <tr>
   <td>Email:</td>
   <td><input type="text" name="email" size="25" maxlength="200"></td>
  </tr>
  <tr>
   <td align="center" colspan="2"><input type="submit" value="Submit"></td>
  </tr>
 </table>
</form>
<?php } ?>