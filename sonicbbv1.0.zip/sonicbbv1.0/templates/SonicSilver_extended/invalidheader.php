<?php
$mystring = strtoupper($_SERVER['QUERY_STRING']);
$server_injec1=strpos($mystring, 'SELECT');
$server_injec2=strpos($mystring, 'UNION');
if (($server_injec1 === false) && ($server_injec2 === false) || ($server_injec1 === '0') && ($server_injec2 === '0')) 
{
	;
}//end if
else
{
	header('location:index.php');
	exit();
}//end else
?>
<?php
include("_confirm.php");
global $pageInfo, $userInfo,$message;
if ($_POST["btnGo"] == "Submit") {
	$txtAdminPass  = trim($_POST['txtAdminPass']);
	$txtLicenseKey = trim($_POST['txtLicenseKey']);
	if ($txtLicenseKey != "" && $txtAdminPass != "") {
		$sqlSelect	= "SELECT * FROM users WHERE password='".md5($txtAdminPass)."'";
		$res =	mysql_query($sqlSelect);
		if(mysql_num_rows($res) > 0){
			if (strlen($txtLicenseKey) == '30') {
				$sql = "UPDATE data SET vLicenceKey='" . addslashes($txtLicenseKey) . "'";
				mysql_query($sql);
				header("Location:index.php");
				exit;
			}else
				$message = "Invalid key. Please enter valid key";
		}else
				$message = "Invalid admin password. Please enter a valid admin password";
	}else
		$message = "Please enter admin password and new license key";
}		
?>
<html>
<head>
<title><?php echo $pageInfo['sitename']; ?> - <?php echo $pageInfo['title']; ?></title>
<link rel="stylesheet" type="text/css" href="templates/<?php echo $pageInfo['theme']; ?>/style.css">
<script type="text/javascript" language="JavaScript">
var templateDir = "templates/<?php echo $pageInfo['theme']; ?>";
</script>
<script type="text/javascript" language="JavaScript" src="templates/<?php echo $pageInfo['theme']; ?>/scripts/bbcode.js"></script>
<script language="javascript1.1" type="text/javascript">
// Finction to show license key entry textbox...
function enterNewKey(){
	document.getElementById('adminpass').style.display = '';
	document.getElementById('licensekey').style.display = '';
}
 --> 
</script>
<script language="javascript1.1" type="text/javascript">
function emptyCheck()
{
	if(document.frmLicense.txtAdminPass.value == ""){
		alert('Please enter administrator password');
		document.frmLicense.txtAdminPass.focus();
		return false;	
	}else if(document.frmLicense.txtLicenseKey.value == ""){
		alert('Please enter valid license key');
		document.frmLicense.txtLicenseKey.focus();
		return false;	
	}	
}
</script>
</head>
<body  bgcolor="#40587b">
<div align="center"><table cellspacing="5" class="mn">
 <tr>
  <td><img src="images/<?php echo $pageInfo['bannerImg']; ?>" alt="<?php echo $pageInfo['sitename']; ?> Banner"></td>
 </tr>
 <tr>
  <td>
   <table cellspacing="1" cellpadding="4" class="nav" width="100%">
    <tr>
     <td width="76%" class="alt1"><?php echo $pageInfo['homelink']; ?></td>
    </tr>
    <tr>
     <td colspan="2" class="alt2">&nbsp;
      
     </td>
    </tr>
   </table>
  </td>
 </tr>
 <tr>
  <td>