<?php
include("_confirm.php");
global $do, $page, $userInfo;
?>
<table width="100%">
 <tr>
  <td valign="top" width="150px">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5">Sidebar</td></tr>
    <tr><td class="alt8"><a href="usercp.php">User CP</a></td></tr>
    <tr><td class="alt8"><a href="members.php?id=<?php echo $userInfo['id']; ?>">View Profile</a></td></tr>
    <tr><td class="alt8"><a href="usercp.php?do=Change Profile">Change Profile</a></td></tr>
   </table>
  </td>
  <td valign="top">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5"><b>User CP<?php
if ($do != "") {
 echo " - ".$do;
}
?></b></td></tr>
    <tr>
     <td class="alt8">
<?php
echo $page;
?>
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table><br />