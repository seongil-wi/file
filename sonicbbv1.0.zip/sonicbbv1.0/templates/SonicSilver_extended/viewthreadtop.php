<?php
include("_confirm.php");
global $userInfo, $pageInfo, $id, $locked, $maxPerPage, $p, $oldcount;

if ($locked && @$userInfo['title'] != "Administrator") {
 echo "<b>This forum is locked.</b><br /><br />\n";
}
else {
?>
<a href="reply.php?id=<?php echo "{$id}&p={$p}"; ?>"><img src="templates/<?php echo $pageInfo['theme']; ?>/images/reply.gif" border="0"></a><br /><br />
<?php
}

$pagecount = ceil($oldcount / $maxPerPage);
echo "Page: ";
if ($p > 1) {
 $prev = $p - 1;
 echo "<a href=\"?id={$id}&p={$prev}\">Previous</a>&nbsp;\n";
}
for ($i=0; $i<$pagecount; $i++) {
 if (($i+1) == $p) {
  echo "<b>{$p}</b>&nbsp;\n";
 }
 else {
  echo "<a href=\"?id={$id}&p=" . ($i+1) . "\">" . ($i+1) . "</a>&nbsp;\n";
 }
}
if ($p < $pagecount) {
 $prev = $p + 1;
 echo "<a href=\"?id={$id}&p={$prev}\">Next</a>&nbsp;\n";
}
echo "<br /><br />\n";
?>