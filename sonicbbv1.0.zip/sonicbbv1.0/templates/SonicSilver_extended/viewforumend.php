<?php include("_confirm.php"); ?>
</table><br />
<?php
global $id, $locked, $userInfo, $p, $maxPerPage, $offset, $oldcount;
?>
<?php
$pagecount = ceil($oldcount / $maxPerPage);

echo "Page: ";

if ($p > 1) {
 $prev = $p - 1;
 echo "<a href=\"?id={$id}&p={$prev}\">Previous</a>&nbsp;\n";
}
for ($i=0; $i<$pagecount; $i++) {
 if (($i+1) == $p) {
  echo "<b>{$p}</b>&nbsp;\n";
 }
 else {
  echo "<a href=\"?id={$id}&p=" . ($i+1) . "\">" . ($i+1) . "</a>&nbsp;\n";
 }
}
if ($p < $pagecount) {
 $prev = $p + 1;
 echo "<a href=\"?id={$id}&p={$prev}\">Next</a>&nbsp;\n";
}
?><br /><br />
<?php
if ($locked && @$userInfo['title'] != "Administrator") {
 echo "<b>This forum is locked.</b>";
}
else {
 echo "<a href=\"newthread.php?id={$id}\"><img src=\"templates/{$pageInfo['theme']}/images/newthread.gif\" border=\"0\"></a>";
}
?><br />
<center>
 <table cellspacing="5" cellpadding="0">
  <tr>
   <td><img src="templates/<?php echo $pageInfo['theme']; ?>/images/sticky.gif"></td>
   <td>Sticky Thread</td>
  </tr>
 </table>
</center><br />