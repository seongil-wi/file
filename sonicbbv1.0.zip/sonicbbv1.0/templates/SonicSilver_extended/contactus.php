<?php
include("_confirm.php");
global $do, $page, $userInfo;
?>
<table width="100%">
 <tr>
  <td valign="top">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5"><b>Contact Us<?php
if ($do != "") {
 echo " - ".$do;
}
?></b></td></tr>
    <tr>
     <td class="alt8">
<?php
echo "<div align=justify>        
           <p align='left'>
				<B>84 Whitman Drive<br>
					Schaumburg, IL 60173<br>
					US of A</B> <br>&nbsp;<br>&nbsp;<br>

					<b>Tel.:</b> 1-(312)-423-6728 <br>

					<b>Fax.:</b> 1-(978)-268-7624<br>
					<b>E-mail:</b> sales@iscripts.com<br>
 		  </p>
</div>";
?>
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table><br />