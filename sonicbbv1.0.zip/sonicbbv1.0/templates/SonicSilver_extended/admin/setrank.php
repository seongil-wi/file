<?php
include("_confirm.php");

$ranks = array("Member", "Moderator", "Administrator");

$bdo = @$_POST['bdo'];
if ($bdo == "") {
?>
<form method="post" action="?do=setrank">
 <input type="hidden" name="bdo" value="set">
 <table style="color: black">
  <tr>
   <td align="right"><b>User:</b></td>
   <td><input type="text" name="user" maxlength="200"></td>
  </tr>
  <tr>
   <td align="right"><b>Rank:</b></td>
   <td>
    <select name="rank">
     <option value="1" />Member
     <option value="2" />Moderator
     <option value="3" />Administrator
    </select>
   </td>
  </tr>
  <tr>
   <td align="center" colspan="2"><input type="submit" value="Set Rank"></td>
  </tr>
 </table>
</form>
<?php
}
else if ($bdo == "set") {
 $user = @$_POST['user'];
 $rank = @$_POST['rank'];
 if ($user && $rank) {
  $q = mysql_query("SELECT * FROM `users` WHERE username='$user'");
  $q = mysql_fetch_array($q);
  if ($q) {
   $rank = $ranks[$rank-1];
   $q = mysql_query("UPDATE `users` SET title='{$rank}', subtitle='{$rank}'  WHERE username='{$user}'");
   if ($q) {
    echo "<font color=red>The member <b>{$user}</b> has been set to <b>{$rank}</b>.</font>";
   }
   else {
    echo "<font color=red>Unable to set the rank for <b>{$user}</b>. Please try again later.</font>";
   }
  }
  else {
   echo "<font color=red>The member <b>{$user}</b> does not exist.</font>";
  }
 }else {     //    updated by roshith on 7-8-06
    echo "<font color=red>You must fill in the user field.</font>";
 }
    echo "<br /><br />\n<a href=\"?do=setrank\">[ Back ]</a>\n";
}
?>