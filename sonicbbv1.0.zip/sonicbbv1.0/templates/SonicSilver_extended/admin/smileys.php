<?php
include("_confirm.php");

//////////  added by roshith on 12-8-06 for sonicBB
function ResizeImageTogivenWitdhAndHeight($file, $img_height, $img_width, $tosavefileas = null)
{
    if (!isset($tosavefileas)) {
        $tosavefileas = $file;
    }

    $img_temp = NewimageCreatefromtype($file);
    $black = @imagecolorallocate ($img_temp, 0, 0, 0);
    $white = @imagecolorallocate ($img_temp, 255, 255, 255);
    $font = 2;
    $cuurentimagewidth = @imagesx($img_temp);
    $cuurentimageheight = @imagesy($img_temp);

    list($originalwidth, $originalheight, $originaltype) = getimagesize($file);
    if ($originaltype == "1") { // gif
        $newwidth = $img_width;
        $newheight = $img_height;
        $tpcolor = imagecolorat($img_temp, 0, 0);
        // in the real world, you'd better test all four corners, not just one!
        $img_thumb = imagecreate($newwidth, $newheight);
        // $dest automatically has a black fill...
        imagepalettecopy($img_thumb, $img_temp);
        imagecopyresized($img_thumb, $img_temp, 0, 0, 0, 0, $newwidth, $newheight,
            @imagesx ($img_temp), @imagesy($img_temp));
        $pixel_over_black = imagecolorat($img_thumb, 0, 0);
        // ...but now make the fill white...
        $bg = imagecolorallocate($img_thumb, 255, 255, 255);
        imagefilledrectangle($img_thumb, 0, 0, $newwidth, $newheight, $bg);
        imagecopyresized($img_thumb, $img_temp, 0, 0, 0, 0, $newwidth, $newheight,
            @imagesx ($img_temp), @imagesy($img_temp));
        $pixel_over_white = imagecolorat($img_thumb, 0, 0);
        // ...to test if transparency causes the fill color to show through:
        if ($pixel_over_black != $pixel_over_white) {
            // Background IS transparent
            imagefilledrectangle($img_thumb, 0, 0, $newwidth, $newheight,
                $tpcolor);
            imagecopyresized($img_thumb, $img_temp, 0, 0, 0, 0, $newwidth,
                $newheight, @imagesx ($img_temp), @imagesy($img_temp));
            imagecolortransparent($img_thumb, $tpcolor);
            imagegif($img_thumb, $tosavefileas);
        } else // Background (most probably) NOT transparent
            imagegif($img_thumb, $tosavefileas);
    } else {
        $img_thumb = @imagecreatetruecolor($img_width, $img_height);
        @imagecopyresampled($img_thumb, $img_temp, 0, 0, 0, 0, $img_width, $img_height, @imagesx ($img_temp), @imagesy($img_temp));
        ReturnImagetype($img_thumb, $tosavefileas, $file);
    }
}

function ReturnImagetype($newImage, $newfile, $editimagefile)
{
    list($width, $height, $type, $attr) = @getimagesize($editimagefile);
    $jpgCompression = "20";
    if ($type == "1") { // gif
        $returnimage = @imagegif($newImage, $newfile);
    } else if ($type == "2") { // jpeg
        $returnimage = @imagejpeg($newImage, $newfile, $jpgCompression);;
    } else if ($type == "3") { // png
        $returnimage = @imagepng($newImage, $newfile);
    } else {
        $returnimage = "Not Supported";
    }
    return $returnimage;
}
function NewimageCreatefromtype($image)
{
    list($width, $height, $type, $attr) = @getimagesize($image);
    if ($type == "1") { // gif
        $returnimage = @imagecreatefromgif($image);
    } else if ($type == "2") { // jpeg
        $returnimage = @imagecreatefromjpeg($image);
    } else if ($type == "3") { // png
        $returnimage = @imagecreatefrompng($image);
    } else {
        $returnimage = "Not Supported";
    }
    return $returnimage;
}

function isValidWebImageType($mimetype,$tempname)
{
	//check if its image file
	if (!getimagesize($tempname))
	{
		return false;
	}
	if(($mimetype=="image/pjpeg") || ($mimetype=="image/jpeg") || ($mimetype=="image/x-png")|| ($mimetype=="image/png")|| ($mimetype=="image/gif")|| 
		($mimetype=="image/x-windows-bmp")|| ($mimetype=="image/bmp") ){
		return true;
	}else{
		return false;
	}
}
///////////


$bdo = @$_GET['bdo'];
if ($bdo == "") {
?>
<b>Add a Smiley:</b><br />
<form method="post" action="?do=smileys&bdo=add" enctype="multipart/form-data">
 <table cellspacing="0" cellpadding="1" style="color: black">
 <tr>
  <td><b>Smiley</b></td>
  <td><b>Key Value</b></td>
 </tr>
  <tr>
   <td><input type="file" name="smiley" id="smiley"></td>
   <td><input type="text" name="keyVal" size="5" maxlength="5"></td>
  </tr>
  <tr>
   <td colspan="2" align="center"><input type="submit" value="Add"></td>
  </tr>
 </table>
</form>
Change the permission (chmod) of 'images/smileys' folder to 777. All smileys are located in the images/smileys folder. Key Value is the text a person must type in order for the smiley to show up.<br /><br />
<b>Current Smileys:</b><br />
<table cellspacing="0" cellpadding="1" style="color: black">
 <tr>
  <td width=10>&nbsp;</td>
  <td><b>Key Value</b></td>
  <td><b>Smiley</b></td>
 </tr>
<?php
 $q = mysql_query("SELECT * FROM `smileys`");
 $c = mysql_num_rows($q);
 $smileydir = "images/smileys/";
 while ($row = mysql_fetch_array($q)) {
?>
 <tr>
  <form method="post" action="?do=smileys&bdo=change&id=<?php echo $row['id']; ?>" style="display: inline">
   <td  width=10>&nbsp;</td>
   <td><input type="text" name="keyVal" value="<?php echo $row['keyVal']; ?>" size="5" maxlength="5"></td>
   <td align=center><? if(file_exists($smileydir.$row['src']))
          {  ?>
            <img src="<?php echo $smileydir.$row['src']; ?>">
       <? }
       ?>
   </td>
   <td><input type="submit" value="Change"></td>
  </form>
  <form method="post" action="?do=smileys&bdo=delete&id=<?php echo $row['id']; ?>" style="display: inline">
   <td><input type="submit" value="Delete"></td>
  </form>
 </tr>
<?php
 }
 if ($c == 0) {
?>
 <tr>
  <td colspan="2" align="center"><b>No Smileys Exist</b></td>
 </tr>
<?php
 }
?></table><?php
}
else if ($bdo == "change") {
 $id = @$_GET['id'];
 if ($id == "") {
  echo "<font color=red>No ID found.</font>";
 }
 else {
//  $src = @$_POST['src'];
  $keyVal = @$_POST['keyVal'];
  $q = mysql_query("SELECT * FROM `smileys` WHERE keyVal='$keyVal' AND id!='$id'");
  $q = mysql_fetch_array($q);
  if ($q) {
   echo "<font color=red>The key value <b>{$keyVal}</b> has already been used.</font>";
  }
  else {
   $q = mysql_query("UPDATE `smileys` SET keyVal='$keyVal' WHERE id='$id'");
   if ($q) {
    echo "<font color=red>The smiley has been updated.</font>";
   }
   else {
    echo "<font color=red>Unable to update smiley - it may not exist. Please try again later.</font>";
   }
  }
 }
 echo "<br /><br />\n<a href=\"?do=smileys\">[ Back ]</a>\n";
}
else if ($bdo == "delete") {
 $id = @$_GET['id'];
 if ($id == "") {
  header("Location: ?do=smileys");
 }
 else {
  $q = mysql_query("DELETE FROM `smileys` WHERE id='$id'");
  if ($q) {
   echo "<font color=red>The smiley has been deleted.</font>";
  }
  else {
   echo "<font color=red>Unable to delete smiley - it may not exist. Please try again later.</font>";
  }
 }
 echo "<br /><br />\n<a href=\"?do=smileys\">[ Back ]</a>\n";
}
else if ($bdo == "add") {

////// added by roshith on 12-8-06

    $smileydir = "images/smileys/";

    $smileyfile = $_FILES['smiley'][0];
    $smileyfilename = $_FILES['smiley']['name'];
	$logotempname	= $_FILES['smiley']['tmp_name'];
    $smileyfiletype = $_FILES['smiley']['type'];

    $smileyimagedest = $smileydir . $smileyfilename;
    $wmfilesmalldest = $smileydir . $wmfilesmallname;
    $wmfilebigdest = $smileydir . $wmfilebigname;

    if($smileyfilename !=""){
        if (!is_writable($smileydir) || !is_readable($smileydir) || !@file_exists("$smileydir".".")  ) {
            $error = true;
            $message .= " * Change the permission of 'images/smileys' folder in the root to 777 <br>";
        }

        if ($smileyfiletype != "") {
            if (!isValidWebImageType($smileyfiletype,$logotempname)) {
                $message .= " * Invalid smiley file ! Upload an image (jpg/gif/bmp/png)" . "<br>";
                $error = true;
            }
        }
   }

   if($error == "true"){
     echo "<font color=red>$message</font>\n";
   }else{
        //uploading smiley

        if($smileyfilename == ""){
                $smileyfilename = "";
        }else if (move_uploaded_file( $_FILES['smiley']['tmp_name'], $smileyimagedest)) {
                 chmod($smileyimagedest,0777);
                 list($originalwidth, $originalheight, $originaltype) = getimagesize($smileyimagedest);
                 if($originalwidth<=20 and $originalheight<=20){
                                                  ;
                 }else{
                          $resizedimage=$smileyimagedest;
                          if($originalwidth >=20){
                                 $imagewidth=20;
                          }else{
                                 $imagewidth=$originalwidth;
                          }
                          if($originalheight >=20){
                                 $imageheight=20;
                          }else{
                                 $imageheight=$originalheight;
                          }
                          ResizeImageTogivenWitdhAndHeight($smileyimagedest.$file_name,$imageheight,$imagewidth,$resizedimage);
                 }
       }
/////////////

    // $src = @$_POST['src'];
    $keyVal = @$_POST['keyVal'];
    if ($smileyfilename && $keyVal) {
      $q = mysql_query("INSERT INTO `smileys` VALUES ('','$smileyfilename', '$keyVal')");
      if ($q) {
       echo "<font color=red>Your smiley has been added.</font>";
      }else {
       echo "<font color=red>Unable to add new smiley. Please try again later.</font>";
      }
    }else {
      echo "<font color=red>A smiley must have a Smiley SRC and a Key Value.</font>";
    }
  }
     echo "<br /><br />\n<a href=\"?do=smileys\">[ Back ]</a>\n";
}
?>