<?php
include("_confirm.php");

$id = @$_GET['id'];

$q = mysql_query("SELECT * FROM `forums` WHERE id='$id'");
$q = mysql_fetch_array($q);

$error = "";
if (!$q) {
 $error = "<font color=red>That forum does not exist.</font>";
}

if ($error) {
 echo "<br><font color=red>".$error."</font>";
 echo "<br /><br />\n<a href=\"admin.php?do=frmmg\">[ Back ]</a>\n";
}
else {
 $cdo = @$_POST['cdo'];
 if ($cdo == "") {
?>
<form method="post" action="admin.php?do=frmmg&bdo=edtfrm&id=<?php echo $id; ?>">
 <input type="hidden" name="cdo" value="edt">
 <table class="hmd">
  <tr>
   <td align="right"><b>Name:</b></td>
   <td><input type="text" name="nm" value="<?php echo $q['name']; ?>" maxlength="200"></td>
  </tr>
  <tr>
   <td align="right"><b>Discription:</b></td>
   <td><input type="text" name="disc" value="<?php echo $q['discription']; ?>" maxlength="255"></td>
  </tr>
  <tr>
   <td align="right"><b>Category:</b></td>
   <td>
    <select name="cat">
<?php
$q2 = mysql_query("SELECT * FROM `cats`");
while ($row = mysql_fetch_array($q2)) {
 $c = "";
 if ($row['id'] == $q['inCat']) $c = " selected=\"selected\"";
 echo "<option value=\"{$row['id']}\"{$c}>{$row['name']}\n";
}
?>
    </select>
   </td>
  </tr>
  <tr>
   <td align="right"></td>
   <td>
    <select name="lck">
<?php
$c = $q['locked'] == 0 ? " selected=\"selected\"" : "";
?>
     <option value="1"<?php echo $c; ?>>Locked
     <option value="0"<?php echo $c; ?>>Un-Locked
    </select>
   </td>
  </tr>
  <tr>
   <td><input type="submit" value="Edit"></td>
  </tr>
 </table>
</form>
<?php
 }
 else if ($cdo == "edt") {
  $nm = @$_POST['nm'];
  $disc = @$_POST['disc'];
  $cat = @$_POST['cat'];
  $lck = @$_POST['lck'];
  if ($nm && $cat >= 0 && $lck >= 0) {
   $q = mysql_query("UPDATE `forums` SET name='$nm', discription='$disc', inCat='$cat', locked='$lck' WHERE id='$id'");
   if ($q) {
    echo "<font color=red>The forum {$q['name']} has been updated successfully.</font>";
   }
   else {
    echo "<font color=red>Unable to update forum {$q['name']}. Please try again later.</font>";
   }
   echo "<br /><br />\n<a href=\"admin.php?do=frmmg&bdo=edtfrm&id={$id}\">[ Back ]</a>\n";
  }
  else {
   echo "<font color=red>A forum needs a name, category, and whethor or not its locked/un-locked.</font>";
   echo "<br /><br />\n<a href=\"admin.php?do=frmmg&bdo=edtfrm&id={$id}\">[ Back ]</a>\n";
  }
 }
}
?><br />
<a href="admin.php?do=frmmg">[ Back to Forum Management ]</a>