<?php
include("_confirm.php");
global $userInfo, $pageInfo;
?>
Welcome to the administration, <?php echo $userInfo['username']; ?>!<br /><br />

Last login on <?php
$lgn = $pageInfo['lastAdminLogin'];
if (!$lgn) {
 echo "<b>none recorded</b>";
}
else {
 echo date("l, F j, Y g:ia", $lgn);
}

mysql_query("UPDATE `data` SET lastAdminLogin='".time()."'");
?>.