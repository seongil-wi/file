<?php
include("_confirm.php");

$id = @$_GET['id'];

$delforumid ="";

$q = mysql_query("SELECT * FROM `cats` WHERE id='$id'");
$q = mysql_fetch_array($q);

if (!$q) {
 echo "<font color=red>The Category does not exist.</font>";
}
else {

///// added by roshith on 12-8-06
// to delete all the entries from the tables posts,threads,forums of the selected category /////
   $sql = "SELECT * FROM `forums` WHERE inCat='{$q['id']}'";
   $q2 = mysql_query($sql);
   while($row = mysql_fetch_array($q2)){
     $delforumid = $delforumid.$row['id'].",";
   }

   $delforumid = substr($delforumid,0,-1);

   $q3 = mysql_query("DELETE FROM `cats` WHERE id='$id'");
   $q4 = mysql_query("DELETE FROM `forums` WHERE inCat='{$id}'");

   $sqlthread = "DELETE FROM `threads` WHERE inForum in ($delforumid)";
   $sqlpost = "DELETE FROM `posts` WHERE inForum in ($delforumid)";

   $q5 = mysql_query($sqlthread);
   $q6 = mysql_query($sqlpost);

/////////////////////////

 if ($q3 && $q4) {
  echo "<font color=red>The category '<b>{$q['name']}</b>' and its forums have been deleted!</font>";
 }
 else {
  echo "<font color=red>Unable to delete category '<b>{$q['name']}</b>' and its forums. Please try again later.</font>";
 }
}
?><br /><br />
<a href="admin.php?do=frmmg">[ Back ]</a>