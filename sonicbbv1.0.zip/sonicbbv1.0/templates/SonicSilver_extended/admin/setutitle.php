<?php
include("_confirm.php");

$bdo = @$_POST['bdo'];
if ($bdo == "") {
?>
<form method="post" action="?do=usertitle">
 <input type="hidden" name="bdo" value="set">
 <table style="color: black">
  <tr>
   <td align="right"><b>User:</b></td>
   <td><input type="text" name="user" size="15" maxlength="200"></td>
  </tr>
  <tr>
   <td align="right"><b>Title:</b></td>
   <td><input type="text" name="title" size="15" maxlength="255"></td>
   <td>HTML Allowed</td>
  </tr>
  <tr>
   <td colspan="2" align="center"><input type="submit" value="Set User Title"></td>
  </tr>
 </table>
</form>
<?php
}
else if ($bdo == "set") {
 $user = @$_POST['user'];
 $title = addslashes(@$_POST['title']);
 if ($user && $title) {
  $q = mysql_query("SELECT * FROM `users` WHERE username='$user'");
  $q = mysql_fetch_array($q);
  if ($q) {
   $q = mysql_query("UPDATE `users` SET subtitle='$title' WHERE username='$user'");
   if ($q) {
    echo "<font color=red><b>{$user}</b>'s Custom Title has been set to \"" . stripslashes($title) . "\".</font>";
   }
  }
  else {
   echo "<font color=red>The user <b>{$user}</b> does not exist.</font>";
  }
//  echo "<br /><br />\n<a href=\"?do=usertitle\">[ Back ]</a>\n";
 }
 else {
//  header("Location: admin.php?do=usertitle");    changed by roshith on 7-8-06
  echo "<font color=red>You must fill in the user field and title.</font>";
//  echo "<br /><br />\n<a href=\"?do=usertitle\">[ Back ]</a>\n";
 }
   echo "<br /><br />\n<a href=\"?do=usertitle\">[ Back ]</a>\n";
}
?>