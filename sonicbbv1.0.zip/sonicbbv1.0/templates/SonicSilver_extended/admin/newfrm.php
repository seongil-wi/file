<?php
include("_confirm.php");

$cdo = @$_POST['cdo'];
if ($cdo == "") {
?>
<form method="post" action="admin.php?do=frmmg&bdo=newfrm">
 <input type="hidden" name="cdo" value="crt">
 <table class="hmd">
  <tr>
   <td align="right"><b>Name:</b></td>
   <td><input type="text" name="nm" maxlength="200"></td>
  </tr>
  <tr>
   <td align="right"><b>Discription:</b></td>
   <td><input type="text" name="disc" maxlength="255"></td>
  </tr>
  <tr>
   <td align="right"><b>Category:</b></td>
   <td>
    <select name="cat">
<?php
$q = mysql_query("SELECT * FROM `cats`");
while ($row = mysql_fetch_array($q)) {
 echo "<option value=\"{$row['id']}\">{$row['name']}\n";
}
?>
    </select>
   </td>
  </tr>
  <tr>
   <td align="right"></td>
   <td>
    <select name="lck">
     <option value="1">Locked
     <option value="0" selected="selected">Un-Locked
    </select>
   </td>
  </tr>
  <tr>
   <td><input type="submit" value="Create"></td>
  </tr>
 </table>
</form>
<?php
}
else if ($cdo == "crt") {
 $nm = @$_POST['nm'];
 $disc = @$_POST['disc'];
 $cat = @$_POST['cat'];
 $lck = @$_POST['lck'];
 if ($nm && $cat >= 0 && $lck >= 0) {

 // added by roshith on 12-8-06 to check duplicate forum name in the same category//
  $q1 = mysql_query("SELECT * FROM `forums` WHERE name='$nm' AND inCat=$cat");

  if(mysql_num_rows($q1)>0){
    echo "<font color=red>The Forum '<b>{$nm}</b>' already exist!</font>";
  }else {
 /////////////////
    $q = mysql_query("SELECT * FROM `forums` ORDER BY forumOrder DESC");
    $q = mysql_fetch_array($q);
    $fO = $q['forumOrder'];
    if (!$fO) $fO = 0;
    $nextForumOrder = $fO + 1;
    $q = mysql_query("INSERT INTO `forums` VALUES ('','$nm','$disc','$cat','$lck','$nextForumOrder')");
    if ($q) {
     echo "<font color=red>The forum '<b>{$nm}</b>' has been created.</font>";
    }
    else {
     echo "<font color=red>Unable to create forum '<b>{$nm}</b>'. Please try again later.</font>";
    }
  }
 }else {
   echo "<font color=red>A forum needs a name, category, and whether or not its locked/un-locked.</font>";
 }
   echo "<br /><br />\n<a href=\"admin.php?do=frmmg&bdo=newfrm\">[ Back ]</a>\n";
}
  echo "<br />\n<a href=\"admin.php?do=frmmg\">[ Back to Forum Management ]</a>\n";
?>