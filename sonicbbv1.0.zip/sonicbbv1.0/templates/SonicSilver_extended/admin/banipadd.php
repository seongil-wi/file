<?php
include("_confirm.php");
$ip = @$_POST['ip'];
if ($ip == "") {
 echo "<font color=red>No IP address found.</font>";
}
else {
 $q = mysql_query("INSERT INTO `bannedips` VALUES ('', '$ip')");
 if ($q) {
  echo "<font color=red>The IP address {$ip} has been <b>banned</b> from this forum!</font>";
 }
 else {
  echo "<font color=red>Unable to ban the IP address {$ip}. Please try again later.</font>";
 }
}
echo "<br /><br />\n<a href=\"?do=banip\">[ Back ]</a>\n";
?>