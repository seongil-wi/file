<?php include("_confirm.php"); ?>
<form method="post" action="admin.php?do=banip&bdo=add">
 <input type="text" name="ip" maxlength="16">
 <input type="submit" value="Ban IP">
</form><br />
<b>Banned IPs:</b><br />
<?php
$q = mysql_query("SELECT * FROM `bannedips`");
while ($row = mysql_fetch_array($q)) {
 echo "<a href=\"admin.php?do=banip&bdo=unban&id={$row['id']}\">{$row['ip']}</a><br />\n";
}
?>