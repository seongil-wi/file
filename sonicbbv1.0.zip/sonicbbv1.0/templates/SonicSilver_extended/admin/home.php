<?php
include("_confirm.php");
global $do, $page, $userInfo;
?>
<table width="100%">
 <tr>
  <td valign="top" width="150px">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5">Sidebar</td></tr>
    <tr><td class="alt8"><a href="admin.php">Admin Home</a></td></tr>
    <tr><td class="alt8"></td></tr>
    <tr><td class="alt8"><a href="admin.php?do=banip">Ban IP</a></td></tr>
    <tr><td class="alt8"><a href="admin.php?do=smileys">Smileys</a></td></tr>
    <tr><td class="alt8"><a href="admin.php?do=setrank">Set Rank</a></td></tr>
    <tr><td class="alt8"><a href="admin.php?do=usertitle">User Title</a></td></tr>
    <tr><td class="alt8"><a href="admin.php?do=deluser">Delete Member</a></td></tr>
    <tr><td class="alt8"><a href="admin.php?do=frmhd">Forum Home Data</a></td></tr>
    <tr><td class="alt8"><a href="admin.php?do=frmmg">Forum Management</a></td></tr>
   </table>
  </td>
  <td valign="top">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5"><b>Admin CP</b></td></tr>
    <tr>
     <td class="alt8">
<?php
fetchTemplate($page);
?>
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table><br />