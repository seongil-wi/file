<?php include("_confirm.php"); ?>
<form method="post" action="admin.php?do=deluser">
 <input type="hidden" name="bdo" value="del">
 <input type="text" name="user" maxlength="200">
 <input type="checkbox" name="confirm" value="1">Confirm<br /><br />
 <input type="submit" value="Delete">
</form>