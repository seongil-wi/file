<?php
include("_confirm.php");
$id = @$_GET['id'];
if ($id == "") {
 echo "<font color=red>No IP address found.</font>";
}
else {
//////////////   added by roshith on 7-8-06

    $q1 = mysql_query("SELECT * FROM `bannedips` WHERE id='$id'");
    $q1 = mysql_fetch_array($q1);

/////////////

 $q = mysql_query("DELETE FROM `bannedips` WHERE id='$id'");
 if ($q) {
  echo "<font color=red>The IP address '".$q1['ip']. "' has been <b>un-banned</b> from this forum.</font>";
 }
 else {
  echo "<font color=red>Unable to un-ban the IP address '". $q1['ip']. "'. Please try again later.</font>";
 }
}
echo "<br /><br />\n<a href=\"?do=banip\">[ Back ]</a>\n";
?>