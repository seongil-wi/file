<?php
include("_confirm.php");

$id = @$_GET['id'];

$q = mysql_query("SELECT * FROM `forums` WHERE id='$id'");
$q = mysql_fetch_array($q);

if (!$q) {
 echo "<font color=red>The forum does not exist.</font>";
}
else {
 $q2 = mysql_query("DELETE FROM `forums` WHERE id='$id'");
 $q3 = mysql_query("DELETE FROM `threads` WHERE inForum='{$q['id']}'");
 $q4 = mysql_query("DELETE FROM `posts` WHERE inForum='{$q['id']}'");
 if ($q2 && $q3 && $q4) {
  echo "<font color=red>The forum '<b>{$q['name']}</b>' has been deleted!</font>";
 }
 else {
  echo "<font color=red>Unable to delete forum '<b>{$q['name']}</b>'. Please try again later.</font>";
 }
}
?><br /><br />
<a href="admin.php?do=frmmg">[ Back to Forum Management ]</a>