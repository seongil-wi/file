<?php
include("_confirm.php");

$error = "";

$id = @$_GET['id'];
$q = mysql_query("SELECT * FROM `cats` WHERE id='$id'");
$q = mysql_fetch_array($q);

if (!$q['name']) {
 $error = "<font color=red>Category does not exist!</font>";
}

if ($error) {
 echo $error;
}
else {
 $cdo = @$_POST['cdo'];
 if ($cdo == "") {
?>
<form method="post" action="admin.php?do=frmmg&bdo=rencat&id=<?php echo $id; ?>">
 <input type="hidden" name="cdo" value="ren">
 <input type="text" name="newname" value="<?php echo $q['name']; ?>" maxlength="100">
 <input type="submit" value="Rename">
</form>
<?php
 }
 else if ($cdo == "ren") {
  $newname = @$_POST['newname'];
  if (!$newname) {
   echo "<font color=red>A category needs a name!</font><br /><br />\n<a href=\"admin.php?do=frmmg&bdo=rencat&id={$id}\">[ Back ]</a>\n";
  }
  else {
   $q = mysql_query("UPDATE `cats` SET name='$newname' WHERE id='$id'");
   if ($q) {
    echo "<font color=red>Category renamed to '<b>{$newname}</b>'.</font>";
   }
   else {
    echo "<font color=red>Unable to rename category '<b>{$q['name']}</b>' to '<b>{$newname}</b>'. Please try again later.</font>";
   }
   echo "\n<br /><br />\n<a href=\"admin.php?do=frmmg&bdo=rencat&id={$id}\">[ Back ]</a>\n";
  }
 }
}
?><br />
<a href="admin.php?do=frmmg">[ Back to Forum Management ]</a>