<?php
include("_confirm.php");

// first and last category IDs
$q = mysql_query("SELECT * FROM `cats` ORDER BY catOrder ASC LIMIT 1");
$firstCat = mysql_fetch_array($q);
$q = mysql_query("SELECT * FROM `cats` ORDER BY catOrder DESC LIMIT 1");
$lastCat = mysql_fetch_array($q);

$q = mysql_query("SELECT * FROM `cats` ORDER BY catOrder ASC");
while ($row = mysql_fetch_array($q)) {
 if ($row['id'] == $firstCat['id'] && $row['id'] == $lastCat['id']) {
  $moveInfo = "Category cannot be moved.";
 }
 else if ($row['id'] == $firstCat['id']) {
  $moveInfo = "<a href=\"?do=frmmg&bdo=movecat&dir=down&id={$row['id']}\"><i>Down</i></a>";
 }
 else if ($row['id'] == $lastCat['id']) {
  $moveInfo = "<a href=\"?do=frmmg&bdo=movecat&dir=up&id={$row['id']}\"><i>Up</i></a>";
 }
 else {
  $moveInfo = "<a href=\"?do=frmmg&bdo=movecat&dir=up&id={$row['id']}\"><i>Up</i></a> - <a href=\"?do=frmmg&bdo=movecat&dir=down&id={$row['id']}\"><i>Down</i></a>";
 }
 echo "<b>{$row['name']}</b>&nbsp;&nbsp;&nbsp;&nbsp;\n<a href=\"admin.php?do=frmmg&bdo=rencat&id={$row['id']}\">Rename</a>\n - <a href=\"admin.php?do=frmmg&bdo=delcat&id={$row['id']}\">Delete</a> (Cannot be un-done!)\n -- <b>Move:</b> {$moveInfo}\n<ul>\n";

 $q2 = mysql_query("SELECT * FROM `forums` WHERE inCat='{$row['id']}' ORDER BY forumOrder ASC LIMIT 1");
 $firstForum = mysql_fetch_array($q2);
 $q2 = mysql_query("SELECT * FROM `forums` WHERE inCat='{$row['id']}' ORDER BY forumOrder DESC LIMIT 1");
 $lastForum = mysql_fetch_array($q2);

 $q2 = mysql_query("SELECT * FROM `forums` WHERE inCat='{$row['id']}' ORDER BY forumOrder ASC");
 while ($row2 = mysql_fetch_array($q2)) {
  if ($row2['id'] == $firstForum['id'] && $row2['id'] == $lastForum['id']) {
   $moveInfo = "Forum cannot be moved.";
  }
  else if ($row2['id'] == $firstForum['id']) {
   $moveInfo = "<a href=\"?do=frmmg&bdo=movefrm&dir=down&id={$row2['id']}\"><i>Down</i></a>";
  }
  else if ($row2['id'] == $lastForum['id']) {
   $moveInfo = "<a href=\"?do=frmmg&bdo=movefrm&dir=up&id={$row2['id']}\"><i>Up</i></a>";
  }
  else {
   $moveInfo = "<a href=\"?do=frmmg&bdo=movefrm&dir=up&id={$row2['id']}\"><i>Up</i></a> - <a href=\"?do=frmmg&bdo=movecat&dir=down&id={$row2['id']}\"><i>Down</i></a>";
  }
  echo "<li><b>{$row2['name']}</b>&nbsp;&nbsp;&nbsp;&nbsp;\n<a href=\"admin.php?do=frmmg&bdo=edtfrm&id={$row2['id']}\">Edit</a> -\n<a href=\"admin.php?do=frmmg&bdo=delfrm&id={$row2['id']}\">Delete</a> (Cannot be un-done!) -- <b>Move:</b> {$moveInfo}\n</li>\n";
  echo "{$row2['discription']}<br /><br />\n";
 }

 echo "</ul>\n";
}
?>
Options:<br />
<a href="admin.php?do=frmmg&bdo=newcat">Create a New Category</a> -
<a href="admin.php?do=frmmg&bdo=newfrm">Create a New Forum</a>