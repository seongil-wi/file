<?php
include("_confirm.php");

$cdo = @$_POST['cdo'];
if ($cdo == "") {
?>
<form method="post" action="admin.php?do=frmmg&bdo=newcat">
 <input type="hidden" name="cdo" value="new">
 <input type="text" name="nm" maxlength="100">
 <input type="submit" value="Create">
</form>
<?php
}
else if ($cdo == "new") {
 $nm = @$_POST['nm'];
 if ($nm == "") {
  echo "<font color=red>Category must have names.</font>";
 }
 else {
 // added by roshith on 12-8-06 to check duplicate category name//
  $q1 = mysql_query("SELECT * FROM `cats` WHERE name='$nm'");

  if(mysql_num_rows($q1)>0){
    echo "<font color=red>The category '<b>{$nm}</b>' already exist!</font>";
  }else {
 /////////////////
    $q = mysql_query("SELECT * FROM `cats` ORDER BY catOrder DESC");
    $q = mysql_fetch_array($q);
    $cO = $q['catOrder'];
    if (!$cO) $cO = 0;
    $nextID = $cO + 1;
    $q = mysql_query("INSERT INTO `cats` VALUES ('','$nm','$nextID')");
    if ($q) {
     echo "<font color=red>The category '<b>{$nm}</b>' has been created!</font>";
    }
    else {
     echo "<font color=red>Unable to create category '<b>{$nm}</b>'. Please try again later.</font>";
    }
  }
 }
 echo "<br /><br />\n<a href=\"admin.php?do=frmmg&bdo=newcat\">[ Back ]</a>";
}

echo "<br />\n<a href=\"admin.php?do=frmmg\">[ Back to Forum Management ]</a>\n";
?>