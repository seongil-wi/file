<?php
include("_confirm.php");
global $pageInfo;
?>
<form method="post" action="admin.php?do=frmhd" enctype="multipart/form-data">
 <input type="hidden" name="bdo" value="update">
 <input type="hidden" name="bannerimg" value="<? echo $pageInfo['bannerImg']; ?>">  
 <table class="hmd">
  <tr>
   <td align="right"><b>License Key:</b></td>
   <td><input type="text" class="textbox" name="txtLicenseKey" value="<?php echo $pageInfo['vLicenceKey'];?>" size="38" maxlength="40" readonly></td>
   <td>The License key.</td>
  </tr>
  <tr>
   <td align="right"><b>Site Name:</b></td>
   <td><input type="text" name="sitename" value="<?php echo $pageInfo['sitename']; ?>" maxlength="200"></td>
   <td>The name of this forum.</td>
  </tr>
  <tr>
   <td align="right"><b>Default Theme:</b></td>
   <td>
    <select name="theme">
<?php
$d = dir("templates");
while ($entry = $d->read()) {
 if ($entry != "." && $entry != "..") {
  $c = "";                   // changed by roshith on 8-8-06  $pageInfo['theme'] to  $pageInfo['defaultTheme']
  if ($entry == $pageInfo['defaultTheme']) $c = " selected=\"selected\"";
  echo "     <option value=\"".$entry."\"".$c."/>".$entry."\n";
 }
}
?>
    </select>
   </td>
   <td>The default forum style.</td>
  </tr>
  <tr>
   <td align="right"><b>Site Logo:</b></td>
   <td><input type="file" name="sitelogo" id="sitelogo"></td>
   <td>Site Logo is stored in the images folder.</td>
  </tr>
  <tr>
   <td align="right"><b>Users Timeout:</b></td>
   <td><input type="text" name="usrtime" value="<?php echo $pageInfo['usersTimeout']; ?>" maxlength="10"></td>
   <td>Minutes for a user to become in-active.</td>
  </tr>
  <tr>
   <td align="right"><b>Admin E-Mail:</b></td>
   <td><input type="text" name="admemail" value="<?php echo $pageInfo['adminEmail']; ?>" maxlength="255"></td>
   <td>As the administrator, this is your e-mail address.</td>
  </tr>
 </table>
 <input type="submit" value="Update">
</form>