<?php
include("_confirm.php");

//////////  added by roshith on 11-8-06 for sonicBB
function ResizeImageTogivenWitdhAndHeight($file, $img_height, $img_width, $tosavefileas = null)
{
    if (!isset($tosavefileas)) {
        $tosavefileas = $file;
    }

    $img_temp = NewimageCreatefromtype($file);
    $black = @imagecolorallocate ($img_temp, 0, 0, 0);
    $white = @imagecolorallocate ($img_temp, 255, 255, 255);
    $font = 2;
    $cuurentimagewidth = @imagesx($img_temp);
    $cuurentimageheight = @imagesy($img_temp);

    list($originalwidth, $originalheight, $originaltype) = getimagesize($file);
    if ($originaltype == "1") { // gif
        $newwidth = $img_width;
        $newheight = $img_height;
        $tpcolor = imagecolorat($img_temp, 0, 0);
        // in the real world, you'd better test all four corners, not just one!
        $img_thumb = imagecreate($newwidth, $newheight);
        // $dest automatically has a black fill...
        imagepalettecopy($img_thumb, $img_temp);
        imagecopyresized($img_thumb, $img_temp, 0, 0, 0, 0, $newwidth, $newheight,
            @imagesx ($img_temp), @imagesy($img_temp));
        $pixel_over_black = imagecolorat($img_thumb, 0, 0);
        // ...but now make the fill white...
        $bg = imagecolorallocate($img_thumb, 255, 255, 255);
        imagefilledrectangle($img_thumb, 0, 0, $newwidth, $newheight, $bg);
        imagecopyresized($img_thumb, $img_temp, 0, 0, 0, 0, $newwidth, $newheight,
            @imagesx ($img_temp), @imagesy($img_temp));
        $pixel_over_white = imagecolorat($img_thumb, 0, 0);
        // ...to test if transparency causes the fill color to show through:
        if ($pixel_over_black != $pixel_over_white) {
            // Background IS transparent
            imagefilledrectangle($img_thumb, 0, 0, $newwidth, $newheight,
                $tpcolor);
            imagecopyresized($img_thumb, $img_temp, 0, 0, 0, 0, $newwidth,
                $newheight, @imagesx ($img_temp), @imagesy($img_temp));
            imagecolortransparent($img_thumb, $tpcolor);
            imagegif($img_thumb, $tosavefileas);
        } else // Background (most probably) NOT transparent
            imagegif($img_thumb, $tosavefileas);
    } else {
        $img_thumb = @imagecreatetruecolor($img_width, $img_height);
        @imagecopyresampled($img_thumb, $img_temp, 0, 0, 0, 0, $img_width, $img_height, @imagesx ($img_temp), @imagesy($img_temp));
        ReturnImagetype($img_thumb, $tosavefileas, $file);
    }
}

function ReturnImagetype($newImage, $newfile, $editimagefile)
{
    list($width, $height, $type, $attr) = @getimagesize($editimagefile);
    $jpgCompression = "90";
    if ($type == "1") { // gif
        $returnimage = @imagegif($newImage, $newfile);
    } else if ($type == "2") { // jpeg
        $returnimage = @imagejpeg($newImage, $newfile, $jpgCompression);;
    } else if ($type == "3") { // png
        $returnimage = @imagepng($newImage, $newfile);
    } else {
        $returnimage = "Not Supported";
    }
    return $returnimage;
}
function NewimageCreatefromtype($image)
{
    list($width, $height, $type, $attr) = @getimagesize($image);
    if ($type == "1") { // gif
        $returnimage = @imagecreatefromgif($image);
    } else if ($type == "2") { // jpeg
        $returnimage = @imagecreatefromjpeg($image);
    } else if ($type == "3") { // png
        $returnimage = @imagecreatefrompng($image);
    } else {
        $returnimage = "Not Supported";
    }
    return $returnimage;
}

function isValidWebImageType($mimetype,$tempname)
{
	//check if its image file
	if (!getimagesize($tempname))
	{
		return false;
	}
	if(($mimetype=="image/pjpeg") || ($mimetype=="image/jpeg") || ($mimetype=="image/x-png")|| ($mimetype=="image/png")|| ($mimetype=="image/gif")|| 
		($mimetype=="image/x-windows-bmp")|| ($mimetype=="image/bmp") ){
		return true;
	}else{
		return false;
	}
}
///////////

$sitename = addslashes(@$_POST['sitename']);
$theme = @$_POST['theme'];
$bannerimg = @$_POST['bannerimg'];
$usrtime = @$_POST['usrtime'];
$admemail = @$_POST['admemail'];
$sitelogo = addslashes(@$_POST['sitelogo']);
$logofilename = $_FILES['sitelogo']['name'];
$error = false;

if ($sitename && $theme && $usrtime && $admemail) {

////////////// added by roshith on 11-8-06

    $imagedir = "images/";

    $logofile = $_FILES['sitelogo'][0];
    $logofilename = $_FILES['sitelogo']['name'];
	$logotempname = $_FILES['sitelogo']['tmp_name'];
    $logofiletype = $_FILES['sitelogo']['type'];

    $logoimagedest = $imagedir . $logofilename;
    $wmfilesmalldest = $imagedir . $wmfilesmallname;
    $wmfilebigdest = $imagedir . $wmfilebigname;

    if($logofilename !=""){
        if (!is_writable($imagedir) || !is_readable($imagedir) || !@file_exists("$imagedir".".")  ) {
            $error = true;
            $message .= " * Change the permission of 'images' folder in the root to 777 <br>";
        }

        if ($logofiletype != "") {
            if (!isValidWebImageType($logofiletype,$logotempname)) {
                $message .= " * Invalid Logo file ! Upload an image (jpg/gif/bmp/png)" . "<br>";
                $error = true;
            }
        }
   }
/////////////

 if($error == "true"){
     echo "<font color=red>$message</font>\n";
 }else{
///////////

        //uploading logo
//		$logofilename = "";  // for the demo only otherwise comment this line
        if($logofilename == ""){
                $logofilename = $bannerimg;
        }else if (move_uploaded_file( $_FILES['sitelogo']['tmp_name'], $logoimagedest)) {
                 chmod($logoimagedest,0777);
                 list($originalwidth, $originalheight, $originaltype) = getimagesize($logoimagedest);
                 if($originalwidth<=200 and $originalheight<=90){
                                                  ;
                 }else{
                          $resizedimage=$logoimagedest;
                          if($originalwidth >=200){
                                 $imagewidth=200;
                          }else{
                                 $imagewidth=$originalwidth;
                          }
                          if($originalheight >=90){
                                 $imageheight=90;
                          }else{
                                 $imageheight=$originalheight;
                          }
                          ResizeImageTogivenWitdhAndHeight($logoimagedest.$file_name,$imageheight,$imagewidth,$resizedimage);
                 }
        }else{
                  $logofilename = $bannerimg;
        }
/////////////
     $q = mysql_query("UPDATE `data` SET defaultTheme='$theme',usersTimeout='$usrtime',sitename='$sitename',bannerImg='$logofilename',adminEmail='$admemail'");
	 if ($q) {
      echo "<font color=red>Forum Home Data updated successfully.</font>\n";
     }
     else {
      echo "<font color=red>Unable to update Forum Home Data. Please try again later.</font>\n";
     }
 }
}
    else {
     echo "<font color=red>All fields must be filled in correctly.</font>\n";
    }

    ?><br><br>
<a href="admin.php?do=frmhd">[ Back ]</a>