<?php
include("_confirm.php");
global $do, $page, $userInfo;
?>
<table width="100%">
 <tr>
  <td valign="top">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5"><b>About Us<?php
if ($do != "") {
 echo " - ".$do;
}
?></b></td></tr>
    <tr>
     <td class="alt8">
<?php
echo "<div align=justify>SonicBB is developed by Armia Systems Inc, a software development company headquartered in Schaumburg, in the northwest suburbs of Chicago, IL. Armia Systems, Inc. is a software development company focused on web applications. We offer turn-key solutions, including web site creation, e-commerce development, database integration, hosting, and managed services, supporting your organization's total online presence. We at Armia Systems focus on one simple, honest value statement: Our clients' success is our only priority. Armia Systems, Inc, offers the e-business services you need to make your business a success. Web site design, ecommerce development, and custom web software needs will be met with speed and precision by our highly trained team of IT professionals. The professionals at Armia Systems have the skills to handle your most demanding projects. Our staff is skilled in a wide range of information technology tools and techniques. Our project leads and technical architects have more than 20 years of combined software development and business analysis experience. Our junior developers and application engineers are constantly undergoing professional development activities and training to ensure that they meet our standards of excellence.
</div>";
?>
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table><br />