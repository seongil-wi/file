<?php
include("_confirm.php");
global $do, $page, $userInfo;
?>
<table width="100%">
 <tr>
  <td valign="top">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5"><b>Other Products<?php
if ($do != "") {
 echo " - ".$do;
}
?></b></td></tr>
    <tr>
     <td class="alt8">
<?php
echo "<P align=left>&nbsp;</P>
      <P align=left class=maintext style1>Other Products</P>
	  <P>Empower your site with professional scripts developed by our team:</P>
<HR SIZE=1>
<P> <A href='http://www.supportpro.net' target='_blank'>
<IMG src='images/supportdesk.gif' border=0> </A> </P>

<P><font color=blue><STRONG>SupportPRO Supportdesk </STRONG> - Helpdesk Software</font> - <em>Your complete customer care partner!</em><BR>
  <BR>
  SupportPRO SupportDesk is the low-cost and powerful web based Helpdesk system you can ever find on the web!</P>
<p>SupportPRO SupportDesk is developed and maintained with the insight of helping businesses to communicate with their clients effectively. Years of experience in handling customers from the web hosting industry in particular has made us able to model the software in the most efficient and flexible way.</p>
<p>SupportDesk is so flexible; one can use it to automate virtually any manual process that needs tracking, routing or managing.</p>
<P><A href='http://www.supportpro.net' target=_blank  style='color:#0000CC;'>Learn more about SupportPRO Supportdesk</A></P>

<P><A href='http://www.supportpro.net/order.php' target=_blank   style='color:#0000CC;'>Order SupportPRO Supportdesk</A></P>

<HR SIZE=1>
<P><A href='http://www.iscripts.com/directory'><IMG src='images/directorybrowsing.gif' border=0></A></P>
<P><font color=blue><STRONG>iScripts Direcory Browsing </STRONG> - Directory Script</font> - <em>Fully configurable directory script.</em><BR>
  <BR>
  DirectoryBrowsing is a multi-purpose, powerful, full-featured and secure Business Directory script using PHP scripting language and mySQL database.<br>

  <br>
  DirectoryBrowsing is a professional, fast and reliable tool to make your visitors get the information they were looking for in the best possible way!</P>
<P><A href='http://directory.iscripts.com/' target=_blank  style='color:#0000CC;'>Learn more about iScripts Directory Browsing </A></P>
<P><A href='http://directory.iscripts.com/buynow.php' target=_blank    style='color:#0000CC;'>Order iScripts Directory Browsing</A></P>

<HR SIZE=1>
<P><A href='http://gallery.iscripts.com' target='_blank'> <IMG src='images/imagegallery.gif' border=0> </A> </P>

<P class=maintext><font color=blue><STRONG>iScripts Image Gallery</STRONG> - Image hosting software</font> - Smart image hosting and More! <BR>
  <BR>
  Image Gallery is a web based software that automates the management, organization of images and galleries on your website. Image Gallery is compatible with any web server/operating system combo with PHP 4.x or higher installed and is built on a language and templating system that allows for complete customization into your existing site.</P>
<P class=maintext>Image Gallery is feature packed, supports an unlimited number of images and albums. Image Gallery is a multi-purpose fully-featured and integrated web picture gallery script written in PHP using GD lib with MySQL as backend.</P>
<P> <A href='http://gallery.iscripts.com' target=_blank   style='color:#0000CC;' class=maintext>Learn more about iScripts Image Gallery</A></P>
<P><A href='http://gallery.iscripts.com/buynow.php' target=_blank   style='color:#0000CC;' class=maintext>Order iScripts Image Gallery</A></P>

<HR SIZE=1>
<P><A href='http://www.easycreate.com' target=_blank><IMG src='images/easycreate.gif' border=0></A></P>
<P><font color=blue><STRONG>Easycreate</STRONG>- Online website building software</font> - <em>Start your website building service!</em><BR>

  <BR>
  <SPAN class=maintext>Easycreate is an online website building tool that could be hosted on your server to provide web site building services to your clients. Easycreate is completely custamizable. You can decide on the branding of the entire web site creation software by setting your logo, brand information, marketing messages, special offers, custom support links, etc. on the application interface. As the application is hosted on your server you have the complete control over the working of the site. The application is extremely easy to install you can make your web site building service up and running in minutes.</SPAN></P>
<P><A href='http://www.easycreate.com/' target=_blank  style='color:#0000CC;'>Learn more about Easycreate </A></P>
<P><A href='http://easycreate.com/pricing.php' target=_blank    style='color:#0000CC;'>Order Easycreate </A></P>

<HR SIZE=1>
<P><A href='http://www.survey.iscripts.com/' target=_blank><IMG src='images/easysurvey.gif' border=0></A></P>
<P><font color=blue><STRONG>Easysurveys</STRONG>- Online survey software</font><BR>

  <BR>
  <SPAN class=maintext>Easy Surveys is a survey software application developed mainly for researchers, evaluators and organizational improvement specialists.<br>
     <br>
        It could be hosted on your site and could be integrated with your existing databases.You can create electronic surveys with unlimited questions and answer methods for data collection, analysis and reporting.<br></SPAN></P>
<P><A href='http://www.survey.iscripts.com/' target=_blank  style='color:#0000CC;'>Learn more about Easysurveys </A></P>
<P><A href='http://www.survey.iscripts.com/pricing.php' target=_blank    style='color:#0000CC;'>Order Easysurveys </A></P>";
?>
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table><br />