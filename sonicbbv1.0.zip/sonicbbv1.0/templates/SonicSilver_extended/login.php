<?php
include("_confirm.php");

global $userInfo, $redir;
if ($userInfo['loggedin']) {
 header("Location: index.php");
}
else if (@$_GET['do'] == "login") {

}
else { ?>
<form method="post" action="login.php?do=login&redir=<?php echo $redir; ?>">
 <table align="center" width=300>
  <tr>
   <td>Username:</td>
   <td><input type="text" name="user" size="15" maxlength="200"></td>
  </tr>
  <tr>
   <td>Password:</td>
   <td><input type="password" name="pass" size="15" maxlength="200"></td>
  </tr>
  <tr>
   <td align="center" colspan="2"><input type="submit" value="Login"></td>
  </tr>
  <tr>
   <td align="center" colspan="2" class="navlinks"><a href="forgotpass.php">Forgot Password?</a></td>
  </tr>
 </table>
</form>
<?php } ?>