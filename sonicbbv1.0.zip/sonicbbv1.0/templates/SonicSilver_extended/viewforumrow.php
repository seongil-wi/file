<?php
include("_confirm.php");
global $q, $replys, $lr, $userInfo;
?>
 <tr>
  <td align="center" valign="center" class="alt7"><?php
if ($q['sticky']) {
 echo "<img src=\"templates/{$pageInfo['theme']}/images/sticky.gif\" alt=\"sticky\">";
}
else echo "&nbsp;";
?></td>
  <td valign="top" class="alt8">
   <a href="viewthread.php?id=<?php echo $q['id']; ?>"><?php echo $q['title']; ?></a><br />
   <?php
$q2 = mysql_query("SELECT * FROM `users` WHERE id='{$q['posterId']}'");
$q2 = mysql_fetch_array($q2);
echo "By <a href=\"members.php?id={$q2['id']}\">{$q2['username']}</a><br />\n";
echo date("m-d-y g:ia", $q['date']) . "\n";
?>
  </td>
  <td class="alt7"><?php
if ($replys > 0) {
 $poster = mysql_query("SELECT * FROM `users` WHERE id='{$lr['posterId']}'");
 $poster = mysql_fetch_array($poster);
?>
<b><a href="viewthread.php?id=<?php echo $q['id']; ?>#post<?php echo $lr['id']; ?>"><?php echo $lr['title']; ?></a></b><br />
By <b><a href="members.php?id=<?php echo $poster['id']; ?>"><?php echo $poster['username']; ?></a></b><br />
<?php
 echo date("m-d-y g:ia", $lr['date']);
}
else echo "No replys";
?></td>
  <td align="center" valign="center" class="alt8"><?php echo $replys; ?></td>
  <td align="center" valign="center" class="alt7"><?php echo $q['views']; ?></td>
<?php
if ($userInfo['loggedin'] && ($userInfo['title'] == "Moderator" || $userInfo['title'] == "Administrator")) {
?>
  <td align="center" class="alt8"><a href="modcp.php?do=sticky&id=<?php echo $q['id']; ?>&forum=<?php echo $q['inForum']; ?>">Sticky</a></td>
  <td align="center" class="alt8"><a href="modcp.php?do=del&id=<?php echo $q['id']; ?>&forum=<?php echo $q['inForum']; ?>">Delete</a></td>
<?php } ?>
 </tr>