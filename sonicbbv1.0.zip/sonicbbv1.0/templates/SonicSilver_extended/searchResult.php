<?php
include("_confirm.php");

global $row, $poster, $postPage, $query;
?>
<tr>
 <td class="alt8"><? echo "<a href=\"viewthread.php?id={$row['inThread']}&p={$postPage}#post{$row['id']}\">{$row['title']}</a>\n"; ?></td>
 <td class="alt7"><b><?php echo "<a href=\"members.php?id={$poster['id']}\">{$poster['username']}</a>\n"; ?></b></td>
</tr>