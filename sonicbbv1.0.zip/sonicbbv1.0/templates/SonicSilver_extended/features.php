<?php
include("_confirm.php");
global $do, $page, $userInfo;
?>
<table width="100%">
 <tr>
  <td valign="top">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5"><b>Features<?php
if ($do != "") {
 echo " - ".$do;
}
?></b></td></tr>
    <tr>
     <td class="alt8">
<?php
echo "<p align='left'>
           <ul>
				<li>Easy forum management (add, edit, delete)
				<li>Easy member registration
				<li>Keyword based forum content search
				<li>Simple installation process
				<li>Easy theme selection.
		  </ul>
    </p>";
?>
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table><br />