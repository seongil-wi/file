<?php global $action; ?>
<font size="+1"><b>New Thread</b></font><br /><br />
<form method="post" name="postmsg" action="<?php echo $action; ?>">
 <table>
  <tr>
   <td align="right" valign="top"><b>Title:</b></td>
   <td colspan="2"><textarea name="title" cols="50" rows="1" style="height: 20px; overflow: auto; padding: 0px"><?php echo @$_POST['title']; ?></textarea></td>
  </tr>
  <tr>
   <td align="right"><b>BBCode:</b></td>
   <td colspan="2">
    <a onClick="JavaScript: bbcode('b')" onMouseOver="JavaScript: linkImage(this, 'bbcode_b-over.gif')"  onMouseOut="JavaScript: linkImage(this, 'bbcode_b.gif')" title="Insert a bold BBCode tag."><img src="templates/<?php echo $pageInfo['theme']; ?>/images/bbcode_b.gif"></a>
    <a onClick="JavaScript: bbcode('i')" onMouseOver="JavaScript: linkImage(this, 'bbcode_i-over.gif')"  onMouseOut="JavaScript: linkImage(this, 'bbcode_i.gif')" title="Insert an italic BBCode tag."><img src="templates/<?php echo $pageInfo['theme']; ?>/images/bbcode_i.gif"></a>
    <a onClick="JavaScript: bbcode('u')" onMouseOver="JavaScript: linkImage(this, 'bbcode_u-over.gif')"  onMouseOut="JavaScript: linkImage(this, 'bbcode_u.gif')" title="Insert an underline BBCode tag."><img src="templates/<?php echo $pageInfo['theme']; ?>/images/bbcode_u.gif"></a>
    <a onClick="JavaScript: insertLink()" onMouseOver="JavaScript: linkImage(this, 'bbcode_url-over.gif')"  onMouseOut="JavaScript: linkImage(this, 'bbcode_url.gif')" title="Insert a URL Link BBCode tag."><img src="templates/<?php echo $pageInfo['theme']; ?>/images/bbcode_url.gif"></a>
    <a onClick="JavaScript: bbcode('img')" onMouseOver="JavaScript: linkImage(this, 'bbcode_img-over.gif')"  onMouseOut="JavaScript: linkImage(this, 'bbcode_img.gif')" title="Insert an image BBCode tag."><img src="templates/<?php echo $pageInfo['theme']; ?>/images/bbcode_img.gif"></a>
    <noscript>(<b>JavaScript Required!</b>)</noscript>
   </td>
  </tr>
  <tr>
   <td align="right" valign="top"><b>Post:</b></td>
   <td><textarea name="post" cols="50" rows="10"
   style="width: 425px; overflow: auto" id="post"><?php echo @$_POST['post']; ?></textarea></td>
   <td valign="top" class="smileysBox">
    <center><font face="Verdana"><b><u>Smileys</u></b></font></center><br />
    <?php showSmileys(); ?>
   </td>
  </tr>
  <tr>
  <td><b>Security Code:</b></td>
    <td colspan="2" align="left"><img src="<?php echo 'captcha.php';?>"></td>
  </tr>
   <tr>
  <td>&nbsp;</td>
    <td colspan="2" align="left"><input name="txtSecurity" type="text" class="textarea" size="21" maxlength="10">  <font color="red">*</font></td>
  </tr>
  <tr>
   <td colspan="3" align="center"><input type="submit" value="Post"></td>
  </tr>
 </table>
</form>