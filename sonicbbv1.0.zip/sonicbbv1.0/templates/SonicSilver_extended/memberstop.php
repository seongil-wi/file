<?php include("_confirm.php"); ?>
<br /><table cellspacing="1" cellpadding="5" class="forums">
 <tr>
  <td width="30%" class="alt5">Username</td>
  <td width="40%" class="alt5">Registered On</td>
  <td width="10%" class="alt5" align="center">Posts</td>
  <td width="20%" class="alt5">Rank</td>
 </tr>