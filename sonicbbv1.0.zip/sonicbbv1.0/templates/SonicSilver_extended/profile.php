<?php
include("_confirm.php");
global $q;
?>
<br /><table width="100%" cellspacing="1" cellpadding="5" class="forums">
 <tr>
  <td class="alt5"><?php echo $q['username']; ?></td>
 </tr>
 <tr>
  <td class="alt8">
   <table style="color: black">
    <tr>
     <td colspan="2"><b><i>Member #<?php echo $q['id']; ?></i></b></td>
    </tr>
    <tr>
     <td align="right"><b>Firstname:</b></td>
     <td><?php echo $q['fname']; ?></td>
    </tr>
    <tr>
     <td align="right"><b>Lastname:</b></td>
     <td><?php echo $q['lname']; ?></td>
    </tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr>
     <td colspan="2"><b><i>Messengers:</i></b></td>
    </tr>
    <tr>
     <td align="right"><b>AIM:</b></td>
     <td><?php echo $q['aim']; ?></td>
    </tr>
    <tr>
     <td align="right"><b>MSN:</b></td>
     <td><?php echo $q['msn']; ?></td>
    </tr>
    <tr>
     <td align="right"><b>YIM:</b></td>
     <td><?php echo $q['yim']; ?></td>
    </tr>
    <tr>
     <td align="right"><b>ICQ:</b></td>
     <td><?php echo $q['icq']; ?></td>
    </tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr>
     <td align="right"><b>Avatar:</b></td>
     <td><img src="<?php
$avat = $q['avatar'];
$avat = htmlspecialchars($avat);
$file = $avat;
 if (!preg_match("/^.*\.gif/",$file)) {
  if (!preg_match("/^.*\.jpg/",$file)) {
   if (!preg_match("/^.*\.png/",$file)) {
    $avat = "templates/{$pageInfo['theme']}/images/noavatar.gif";
   }
  }
 }
echo $avat;
?>" width="64" height="64"></td>
    </tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr>
     <td align="right"><b>Signature:</b></td>
     <td><?php
$sig = stripslashes($q['sig']);
$sig = htmlspecialchars($sig);
echo $sig;
?></td>
    </tr>
    <tr><td colspan="2">&nbsp;</td></tr>
    <tr>
<?php
$q2 = mysql_query("SELECT * FROM `posts` WHERE posterId='{$q['id']}'");
$posts = mysql_num_rows($q2);
?>
     <td align="right"><b>Posts:</b></td>
     <td><?php echo $posts; ?></td>
    </tr>
    <tr>
     <td align="right"><b>Registered On:</b></td>
     <td><?php echo date("F j, Y g:ia", $q['reggedOn']); ?></td>
    </tr>
    <tr>
     <td align="right"><b>Rank:</b></td>
     <td><?php echo $q['title']; ?></td>
    </tr>
    <tr>
     <td align="right"><b>Custom Title:</b></td>
     <td><?php
$subtitle = stripslashes($q['subtitle']);
$subtitle = htmlspecialchars($subtitle);
echo $subtitle;
?></td>
    </tr>
   </table>
  </td>
 </tr>
</table><br />