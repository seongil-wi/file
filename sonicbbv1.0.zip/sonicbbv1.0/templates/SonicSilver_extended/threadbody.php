<?php
include("_confirm.php");
global $q2, $poster, $userInfo, $p;
?>
<a name="post<?php echo $q2['id']; ?>"></a>
<table cellspacing="1" cellpadding="4" class="thread">
 <tr>
  <td class="alt5">&nbsp;</td>
  <td class="alt5">
   <span style="float: right"><?php echo date("m-d-y g:ia", $q2['date']); ?></span>
   <a href="#post<?php echo $q2['id']; ?>"><?php echo $q2['title']; ?></a>
  </td>
 </tr>
 <tr>
  <td width="20%" valign="top" class="alt1">
   <a href="members.php?id=<?php echo $poster['id']; ?>"><b><?php echo $poster['username']; ?></b></a><br />
   <?php
$subtitle = stripslashes($poster['subtitle']);
//$subtitle = htmlspecialchars($subtitle);
echo $subtitle;
?><br />
<?php
$file = $poster['avatar'];
 if (!preg_match("/^.*\.gif/",$file)) {
  if (!preg_match("/^.*\.jpg/",$file)) {
   if (!preg_match("/^.*\.png/",$file)) {
    $poster['avatar'] = "templates/{$pageInfo['theme']}/images/noavatar.gif";
   }
  }
 }
?>
   <img src="<?php echo $poster['avatar']; ?>" width="64" height="64"><br /><br />
<?php
$q3 = mysql_query("SELECT * FROM `posts` WHERE posterId='{$poster['id']}'");
$posts = mysql_num_rows($q3);
?>
   Posts: <?php echo $posts; ?><br />
  </td>
  <td valign="top" class="alt8">
   <?php echo $q2['post']; ?><br /><br />
   <?php
   $sig = stripslashes($poster['sig']);
   $sig = nl2br($sig);
   $sig = htmlspecialchars($sig);
   if ($sig) {
    echo "<hr size=\"1\">\n";
    echo $sig . "\n";
   }
   ?>
  </td>
 </tr>
 <tr>
  <td colspan="2" class="alt9">
<?php
if (($userInfo['loggedin'] && $poster['id'] == $userInfo['id']) || ($userInfo['loggedin'] && $userInfo['title'] == "Administrator")) {
?>
   <span style="float: right">
    <a href="post.php?id=<?php echo "{$q2['id']}&do=edit&p={$p}"; ?>">Edit</a>&nbsp;&nbsp;-
    <a href="post.php?id=<?php echo $q2['id']; ?>&do=delete">Delete</a>
   </span>
<?php } else echo "&nbsp;"; ?>
  </td>
 </tr>
</table><br />