<?php
include("_confirm.php");
global $pageInfo;
?>
</table><br />
<center>
 <table cellspacing="5" cellpadding="0">
  <tr>
   <td><img src="templates/<?php echo $pageInfo['theme']; ?>/images/locked.gif"></td>
   <td>Locked Forum</td>
   <td>&nbsp;</td>
   <td><img src="templates/<?php echo $pageInfo['theme']; ?>/images/unlocked.gif"></td>
   <td>Un-Locked Forum</td>
  </tr>
 </table>
</center><br />