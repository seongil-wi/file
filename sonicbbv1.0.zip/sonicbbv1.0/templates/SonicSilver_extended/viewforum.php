<?php
include("_confirm.php");
global $id, $locked, $userInfo, $p, $maxPerPage, $offset, $oldcount;
//echo $oldcount;
if ($locked && @$userInfo['title'] != "Administrator") {
 echo "<b>This forum is locked.</b>";
}
else {
 echo "<a href=\"newthread.php?id={$id}\"><img src=\"templates/{$pageInfo['theme']}/images/newthread.gif\" border=\"0\"></a>";
}
?><br /><br />
<?php
$pagecount = ceil($oldcount / $maxPerPage);

echo "Page: ";
if ($p > 1) {
 $prev = $p - 1;
 echo "<a href=\"?id={$id}&p={$prev}\">Previous</a>&nbsp;\n";
}
for ($i=0; $i<$pagecount; $i++) {
 if (($i+1) == $p) {
  echo "<b>{$p}</b>&nbsp;\n";
 }
 else {
  echo "<a href=\"?id={$id}&p=" . ($i+1) . "\">" . ($i+1) . "</a>&nbsp;\n";
 }
}
if ($p < $pagecount) {
 $prev = $p + 1;
 echo "<a href=\"?id={$id}&p={$prev}\">Next</a>&nbsp;\n";
}
?>
<br /><br />
<table cellspacing="1" cellpadding="5" class="forums">
 <tr>
  <td width="6%" class="alt5">&nbsp;</td>
  <td width="37%" class="alt5">Thread</td>
  <td width="37%" class="alt5" align="center">Last Reply</td>
  <td width="10%" class="alt5" align="center">Replys</td>
  <td width="10%" class="alt5" align="center">Views</td>
<?php
if ($userInfo['loggedin'] && ($userInfo['title'] == "Moderator" || $userInfo['title'] == "Administrator")) {
?>
  <td align="center" class="alt5">Sticky</td>
  <td align="center" class="alt5">Delete</td>
<?php } ?>
 </tr>