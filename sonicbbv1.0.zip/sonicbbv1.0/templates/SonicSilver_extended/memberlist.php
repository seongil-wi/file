<?php
global $q;
include("_confirm.php");
?>
 <tr>
  <td class="alt7"><a href="members.php?id=<?php echo $q['id']; ?>"><b><?php echo $q['username']; ?></b></a></td>
  <td class="alt8"><?php
echo date("F j, Y g:ia", $q['reggedOn']);
?></td>
<?php
$q2 = mysql_query("SELECT * FROM `posts` WHERE posterId='{$q['id']}'");
$posts = mysql_num_rows($q2);
?>
  <td class="alt7" align="center"><?php echo $posts; ?></td>
  <td  class="alt8"><?php echo $q['title']; ?></td>
 </tr>