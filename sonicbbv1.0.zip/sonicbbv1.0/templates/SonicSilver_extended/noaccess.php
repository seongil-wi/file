<?php
include("_confirm.php");
global $pageInfo;

$ip = @$_SERVER['REMOTE_ADDR'];
$date = date("l, F j, Y g:ia", time());
$from = $pageInfo['adminEmail'];
$subject = $pageInfo['sitename'] . " - Unauthorized Access";
$message = $date . "   Your forum, " . $pageInfo['sitename'] . ", has had an unauthorized attempt to login to the Administration Control Panel. The IP address in which the request came from was " . $ip . "   If this IP address does not look familiar, we recommend you ban it immediatly, as this person may try another attempt!";
@mail($from, $subject, $message);
?>
<h2>Unauthorized Access!</h2>

You do not have authorization to access this file. An e-mail has been sent to the administrator about this unauthorized access.<br /><br />