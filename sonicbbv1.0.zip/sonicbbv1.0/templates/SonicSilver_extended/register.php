<?php include("_confirm.php"); ?>
<h2>Register</h2>
<font color="red">*</font> Donates a required field.<br /><br />
<form method="post" action="register.php?do=reg">
 <fieldset>
  <legend><i>Member Information</i></legend>
  <table>
   <tr>
    <td align="right"><b>Username:</b></td>
    <td>
     <input type="text" name="user" size="20" maxlength="200">
     <font color="red">*</font>
     (<b>case-insensitive</b>)
    </td>
   </tr>
   <tr>
    <td align="right"><b>Password:</b></td>
    <td>
     <input type="password" name="pass" size="20" maxlength="200">
     <font color="red">*</font>
     (<b>case-sensitive</b>)
    </td>
   </tr>
   <tr>
    <td align="right"><b>E-Mail:</b></td>
    <td>
     <input type="text" name="email" size="20" maxlength="200">
     <font color="red">*</font>
    </td>
   </tr>
  </table>
 </fieldset>
 <fieldset>
  <legend><i>Personal Information (optional)</i></legend>
  <table>
   <tr>
    <td align="right"><b>First Name:</b></td>
    <td><input type="text" name="fname" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right"><b>Last Name:</b></td>
    <td><input type="text" name="lname" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right"><b>AIM Messanger:</b></td>
    <td><input type="text" name="aim" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right"><b>MSN Messanger:</b></td>
    <td><input type="text" name="msn" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right"><b>YIM Messanger:</b></td>
    <td><input type="text" name="yim" size="20" maxlength="200"></td>
   </tr>
   <tr>
    <td align="right"><b>ICQ Messanger:</b></td>
    <td><input type="text" name="icq" size="20" maxlength="200"></td>
   </tr>
  </table>
 </fieldset>
 <fieldset>
  <legend><i>Signature (optional)</i></legend>
  <textarea name="sig" cols="32" rows="4"></textarea>
  (750 characters max.)
 </fieldset>
 <fieldset>
  <legend><i>Avatar (optional)</i></legend>
  <table>
   <tr>
    <td align="right"><b>Offsite Avatar:</b></td>
    <td><input type="text" name="avat" value="http://" size="20" maxlength="200"></td>
   </tr>
   </table>
    </fieldset>
	<fieldset>
	<legend><i>Captcha Validation</i></legend>
	<table>
    <tr>
    <td align="right"><b>Security Code:</b></td>
    <td><img src="<?php echo 'captcha.php';?>"></td>
   </tr>
    <tr>
    <td align="right">&nbsp;</td>
    <td><input name="txtSecurity" type="text" class="textarea" size="21" maxlength="10">  <font color="red">*</font></td>
   </tr>
  </table>
 </fieldset><br />
 <input type="submit" value="Register">
</form>