<?php
include("_confirm.php");
global $cat;
?>
 <tr>
  <td colspan="5" class="alt6"><?php echo $cat['name']; ?></td>
 </tr>