<?php include("_confirm.php"); ?>
<br /><table cellspacing="1" cellpadding="5" class="forums">
 <tr>
  <td width="6%" class="alt5">&nbsp;</td>
  <td width="37%" class="alt5">Forum</td>
  <td width="37%" class="alt5" align="center">Last Thread</td>
  <td width="10%" class="alt5" align="center">Threads</td>
  <td width="10%" class="alt5" align="center">Posts</td>

 </tr>