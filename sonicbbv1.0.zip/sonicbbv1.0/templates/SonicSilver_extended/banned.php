<?php include("_confirm.php"); ?>
<b>You have been banned from this forum!</b><br /><br />
You are no longer able to view any area of this website. If you believe this is a problem, please contact the forum administrator.<br /><br />