<?php
include("_confirm.php");
global $pageInfo, $userInfo;
?>
<html>
<head>
<title><?php echo $pageInfo['sitename']; ?> - <?php echo $pageInfo['title']; ?></title>
<link rel="stylesheet" type="text/css" href="templates/<?php echo $pageInfo['theme']; ?>/style.css">
<script type="text/javascript" language="JavaScript">
var templateDir = "templates/<?php echo $pageInfo['theme']; ?>";
</script>
<script type="text/javascript" language="JavaScript" src="templates/<?php echo $pageInfo['theme']; ?>/scripts/bbcode.js"></script>
</head>
<body  bgcolor="#40587b">
<div align="center"><table cellspacing="5" class="mn">
 <tr>
  <td><img src="images/<?php echo $pageInfo['bannerImg']; ?>" alt="<?php echo $pageInfo['sitename']; ?> Banner"></td>
 </tr>
 <tr>
  <td>
   <table cellspacing="1" cellpadding="4" class="nav">
    <tr>
     <td width="81%" class="alt1"><?php echo $pageInfo['homelink']; ?></td>
     <td width="19%" align="center" class="alt1">
      <form method="GET" action="search.php" style="display: inline">
       <input type="text" name="query" size="12" style="font-size: 10px">
       <input type="submit" value="Search" style="font-size: 10px">
      </form>
     </td>
    </tr>
    <tr>
     <td colspan="2" class="alt2">
      <table class="navlinks">
       <tr>
        <td align="center"><a href="index.php">Home</a></td>
<?php if ($userInfo['loggedin']) { ?>
        <td align="center"><a href="usercp.php">User CP</a></td>
<?php } else { ?>
        <td align="center"><a href="register.php">Register</a></td>
<?php } ?>
        <td align="center"><a href="search.php">Search</a></td>
        <td align="center"><a href="members.php">Members List</a></td>
<?php if ($userInfo['loggedin']) { ?>
        <td align="center"><a href="logout.php">Logout</a></td>
<?php } else { ?>
        <td align="center"><a href="login.php">Login</a></td>
<?php } ?>
       </td>
      </table>
     </td>
    </tr>
   </table>
  </td>
 </tr>
 <tr>
  <td>