<?php
include("_confirm.php");
?>
<table width="100%" cellspacing="1" cellpadding="4" class="forums">
 <tr>
  <td class="alt5">Advanced Search</td>
 </tr>
 <tr>
  <td class="alt7">
   <form method="GET" action="search.php">
    <b>Search Query:</b> <input type="text" size="15" name="query"><br /><br />
    <b>Search The</b>:
    <select name="part">
     <option value="title" />Title
     <option value="post" />Post Body
    </select><br /><br />
    <b>Order By:</b>
    <select name="order">
     <option value="date" />Date
     <option value="title" />Title
    </select>
    <select name="by">
     <option value="asc" />Ascending
     <option value="desc" />Descending
    </select><br /><br />
    <input type="submit" value="Search">
   </form>
  </td>
 </tr>
</table><br />