<?php include("_confirm.php"); ?>
 <tr>
  <td colspan="5" class="alt7">
   <b>This category does not contain any forums.</b>
  </td>
 </tr>