<?php
include("_confirm.php");
global $id, $lp, $q2;
?>
 <tr>
  <td align="center" valign="center" class="alt7"><?php
if ($q2['locked']) $lck = "locked";
else $lck = "unlocked";
echo "<img src=\"templates/".$pageInfo['theme']."/images/".$lck.".gif\" alt=\"".$lck."\">";
?></td>
  <td valign="top" class="alt8">
   <a href="viewforum.php?id=<?php echo $q2['id']; ?>"><?php echo $q2['name']; ?></a><br />
   <?php
   $disc = stripslashes($q2['discription']);
   echo $disc;
   ?>
  </td>
  <td class="alt7">
<?php
if ($lp) {
 $poster = mysql_query("SELECT * FROM `users` WHERE id='{$lp['posterId']}'");
 $poster = mysql_fetch_array($poster);
?>
   <b><a href="viewthread.php?id=<?php echo $lp['id']; ?>"><?php echo $lp['title']; ?></a></b><br />
   By <b><a href="members.php?id=<?php echo $poster['id']; ?>"><?php echo $poster['username']; ?></a></b><br />
<?php echo date("F j, Y g:ia", $lp['date']); ?>
<?php } else { ?>
No threads.
<?php } ?>
  </td>
<?php
$q3 = mysql_query("SELECT * FROM `threads` WHERE inForum='{$q2['id']}'");
$threads = mysql_num_rows($q3);
$q3 = mysql_query("SELECT * FROM `posts` WHERE inForum='{$q2['id']}'");
$posts = mysql_num_rows($q3);
?>
  <td align="center" valign="center" class="alt8"><?php echo $threads; ?></td>
  <td align="center" valign="center" class="alt7"><?php echo $posts; ?></td>
 </tr>