<?php
include("_confirm.php");
global $do, $page, $userInfo;
?>
<table width="100%">
 <tr>
  <td valign="top">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5"><b>Features<?php
if ($do != "") {
 echo " - ".$do;
}
?></b></td></tr>
    <tr>
     <td class="alt8">
<?php
echo "<p align='left'>
           <ul>
				<li>Unlimited forums and categories! 
				<li>Unlimited members!
				<li>Easy member registration
				<li>Powerful search facility - find posts and threads quickly!
				<li>Fully configurable, categorize your forums into categories
				<li>Simple installation process
				<li>Easy theme selection.
				<li>Smiley support
				<li>Avatar support
				<li>List forum members
				<li>Upload a custom logo for your forum header
				<li>IP address banning
		  </ul>
    </p>";
?>
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table><br />