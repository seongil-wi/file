<?php
include("_confirm.php");
global $pageInfo, $userInfo, $startTime, $startTime;
?>
   <table cellspacing="1" cellpadding="5" class="forums">
    <tr>
     <td class="alt5">Whos Online</td>
    </tr>
    <tr>
     <td class="alt8">
<?php
$timeout = $pageInfo['usersTimeout'] * 60;
$date = time() + $timeout;

if ($userInfo['loggedin']) {
 $q = mysql_query("SELECT * FROM `online` WHERE username='{$userInfo['username']}'");
 $q = mysql_fetch_row($q);
 if (!$q[0]) {
  mysql_query("INSERT INTO `online` VALUES ('','{$userInfo['username']}','$date')");
 }
 else {
  mysql_query("UPDATE `online` SET date='$date' WHERE username='{$userInfo['username']}'");
 }
}
else {
 $md5Ip= md5($_SERVER['REMOTE_ADDR']);
 $q = mysql_query("SELECT * FROM `guests` WHERE user='$md5Ip'");
 $q = mysql_fetch_row($q);
 if (!$q[0]) {
  mysql_query("INSERT INTO `guests` VALUES ('','$md5Ip','$date')");
 }
 else {
  mysql_query("UPDATE `guests` SET date='$date' WHERE user='$md5Ip'");
 }
}

$time = time();
mysql_query("DELETE FROM `online` WHERE date < $time");
mysql_query("DELETE FROM `guests` WHERE date < $time");

$q = mysql_query("SELECT * FROM `online`");
$c = mysql_num_rows($q);
if ($c == 0) {
 mysql_query("TRUNCATE `online`");
}

$q2 = mysql_query("SELECT * FROM `guests`");
$gc = mysql_num_rows($q2);
if ($gc == 0) {
 mysql_query("TRUNCATE `guests`");
}

$queryMembers = mysql_query("SELECT * FROM `users`");
$memberCount = mysql_num_rows($queryMembers);
$queryPosts = mysql_query("SELECT * FROM `posts`");
$postCount = mysql_num_rows($queryPosts);
$queryNewGuy = mysql_query("SELECT id,username FROM `users` ORDER BY id DESC LIMIT 1");
$newGuy = mysql_fetch_array($queryNewGuy);

echo "Our members have posted <b>{$postCount}</b> total posts and we have <b>{$memberCount}</b> members.<br />\n";
echo "Our newest member is <a href=\"members.php?id={$newGuy['id']}\">{$newGuy['username']}</a>.<br /><br />\n";
echo "There is currently {$c} member(s) and {$gc} guest(s) online.<br />\n";
if ($c > 0) echo "<br />";
echo "\n";
while ($row = mysql_fetch_array($q)) {
 $x = mysql_query("SELECT * FROM `users` WHERE username='".$row['username']."'");
 $x = mysql_fetch_array($x);
 echo "<a href=\"members.php?id=".$x['id']."\">" . $row['username'] . "</a>&nbsp;&nbsp;&nbsp;\n";
}
?>
     </td>
    </tr>
   </table><br />
  </td>
 </tr>
 <tr>
  <td class="ftr">
   <form method="post" action="usercp.php?do=theme" name="frm1" style="float: right; display: inline">
    Theme Select:&nbsp;
    <select name="theme" onChange="document.frm1.submit();">
<?php
$c = "";
if (@$userInfo['useDefault'] == true) $c = " selected=\"selected\"";
echo "     <option value=\"0\"{$c} />Use Default\n";
?>
<?php
$d = dir("templates");
while ($entry = $d->read()) {
 if ($entry != "." && $entry != "..") {
  $c = "";
  if (@$userInfo['useDefault'] == false && $entry == $pageInfo['theme']) $c = " selected=\"selected\"";
  echo "     <option value=\"{$entry}\"{$c} />{$entry}\n";
 }
}
?>
    </select>
   </form>
                        <div class="bottommenu"><span class="smalltext">
<a href="index.php">Home</a> |
<a href="usercp.php">User CP</a> |
<a href="search.php">Search</a> |
<a href="members.php">Members List</a>
</span>
                        </div>

   <?php
if ($userInfo['loggedin'] && $userInfo['title'] == "Administrator") {
 echo "<a href=\"admin.php\" target=\"_blank\" class=\"adminLogin\">Login to the Administration</a>";
}
?>
  </td>
 </tr>
 <tr>
  <td align="center" class="navlinks">
   <br />
<?php
$endTime = time();
$secs = $endTime - $startTime;
$mins = $secs / 60;
echo "Page generated in <b>{$secs}</b> seconds.<br /><br />\n";
?>
   <!-- SonicBB Copyright (c) :: DO NOT REMOVE! -->
   Powered by <a href="http://www.iscripts.com/sonicbb/" target="_blank">iScripts SonicBB</a>. A premium product from <a href="http://www.iscripts.com/" target="_blank">iScripts.com</a>
  </td>
 </tr>
</table>
</body>
</html>