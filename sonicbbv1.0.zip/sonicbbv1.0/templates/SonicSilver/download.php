<?php
include("_confirm.php");
global $do, $page, $userInfo;
?>
<table width="100%">
 <tr>
  <td valign="top">
   <table cellspacing="1" cellpadding="4" class="sidebr">
    <tr><td class="alt5"><b>Download<?php
if ($do != "") {
 echo " - ".$do;
}
?></b></td></tr>
    <tr>
     <td class="alt8">
<?php
echo "<br><div align=justify><a href='http://www.sonicbb.com/download/sonicbbv1.0.zip'>SonicBB v1.0</a></div>";
?><br>
<br>
<br>
     </td>
    </tr>
   </table>
  </td>
 </tr>
</table><br />