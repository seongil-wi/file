<?php
include("_confirm.php");
$user = strtolower(@$_POST['user']);
$confirm = @$_POST['confirm'];

if (!$user || !$confirm) {
 echo "<font color=red>You must fill in the user field and check confirm.</font>";
}
else if ($user && $confirm == "1") {

 $q2 = mysql_query("SELECT title FROM `users` WHERE username='$user'"); 
 $q2 = mysql_fetch_array($q2);

 $q1 = mysql_query("SELECT id FROM `users` WHERE username='$user'"); 
 $q1 = mysql_fetch_array($q1);
 if($q1){
	 $q2 = mysql_query("SELECT title FROM `users` WHERE username='$user'"); 
	 $q2 = mysql_fetch_array($q2);
	 if($q2[0] != 'Administrator') {
 
		 $q = mysql_query("DELETE FROM `users` WHERE username='$user'");
		 if ($q) {
		   echo "<font color=red>The member {$user} has been deleted.</font>";
		 }
		 else {
		   echo "<font color=red>Unable to delete member '{$user}'. Please try again later.</font>";
		 }
	 }else {
				echo "<font color=red>Member '{$user}' has Administration rank.Please change it first.</font>";
	 }
 }else {
		   echo "<font color=red>Member '{$user}' does not exist.</font>"; 
 }
}
echo "<br /><br />\n<a href=\"?do=deluser\">[ Back ]</a>\n";
?>