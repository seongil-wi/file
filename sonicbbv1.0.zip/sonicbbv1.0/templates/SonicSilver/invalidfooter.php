<?php
include("_confirm.php");
global $pageInfo, $userInfo, $startTime, $startTime,$message;
?>
<form name=frmLicense method=post action="<?=$_SERVER["PHP_SELF"];?>" onSubmit="return emptyCheck();">
<table cellspacing="1" cellpadding="5" class="forums" width="100%">
	<tr>
    	<td class="alt5" colspan="3">Invalid License</td>
    </tr>
	<tr><td colspan="3">&nbsp;</td></tr>
	<tr><td align="center" colspan="3" class="error"><?php echo $message;?></td></tr>
	<tr><td colspan="3">&nbsp;</td></tr>
	<tr>
    	<td class="alt8" align="center" colspan="3">Invalid License
		   <?php
				if ($userInfo['loggedin'] && $userInfo['title'] == "Administrator") {
					echo "(".$pageInfo['vLicenceKey'].")";
					$var_email	=	'support@iscripts.com';
				}else
					$var_email	=	$pageInfo['adminEmail'];
			?>. Please contact <b><?php echo $var_email;?></b>
		</td>
    </tr>
	<tr><td colspan="3">&nbsp;</td></tr>
	<tr>
		<td bgcolor="#EEEEEE" align="center" class="maintext" colspan="3">Click <a href="javascript: enterNewKey();">here</a> to enter new key
		</td>
	</tr>
	<tr id="adminpass" style="display:none;">
		<td width="44%" align="right" bgcolor="#EEEEEE" class="maintext">Admin password</td>
		<td bgcolor="#EEEEEE" width="20%" align="left">
			<input name="txtAdminPass"  id="txtAdminPass" type="text" class="textbox" size="25" maxlength="40" value="<?php echo htmlentities($txtAdminPass);?>">
		</td>
		<td bgcolor="#EEEEEE" width="20%" align="left">&nbsp;</td>
	</tr>
	<tr id="licensekey" style="display:none;">
		<td width="44%" align="right" bgcolor="#EEEEEE" class="maintext">Enter new license key </td>
		<td bgcolor="#EEEEEE" width="20%" align="left">
			<input name="txtLicenseKey"  id="txtLicenseKey" type="text" class="textbox" size="45" maxlength="40" value="<?php echo htmlentities($txtLicenseKey);?>">
		</td>
		<td width="31%" align="left" bgcolor="#EEEEEE" class="maintext">
			<input type="submit" name="btnGo" value="Submit" class="alt5">
		</td>
	</tr>
	<tr><td colspan="3">&nbsp;</td></tr>
    <tr><td colspan="3">&nbsp;</td></tr>
</table>
</form>
   <br>
  </td>
 </tr>
 <tr>
  <td class="ftr">&nbsp;</td>
 </tr>
 <tr>
  <td align="center" class="navlinks">
   <br>
   <!-- SonicBB Copyright (c) :: DO NOT REMOVE! -->
   Powered by <a href="http://www.iscripts.com/sonicbb/" target="_blank">iScripts SonicBB</a>. A premium product from <a href="http://www.iscripts.com/" target="_blank">iScripts.com</a>
  </td>
 </tr>
</table>
</body>
</html>