<?php
// +----------------------------------------------------------------------+
// | PHP version 4/5                                                      |
// +----------------------------------------------------------------------+
// | Copyright (c) 2005-2006 ARMIA INC                                    |
// +----------------------------------------------------------------------+
// | This source file is a part of sonicBB                                |
// +----------------------------------------------------------------------+
// | Authors: roshith<roshith@armia.com>                          		  |
// +----------------------------------------------------------------------+
require("includes/global.php");

$pageInfo['title'] = "Home";

fetchTemplate("header");

fetchTemplate("catrow");

$query = mysql_query("SELECT * FROM `cats` ORDER BY catOrder ASC");
while ($cat = mysql_fetch_array($query)) {
 fetchTemplate("cate");
 $id = $cat['id'];
 $query2 = mysql_query("SELECT * FROM `forums` WHERE inCat='$id' ORDER BY forumOrder ASC");
 while ($q2 = mysql_fetch_array($query2)) {
  $lp = mysql_query("SELECT * FROM `threads` WHERE inForum='{$q2['id']}' ORDER BY id DESC");
  $lp = mysql_fetch_array($lp);
  fetchTemplate("forumrow");
 }
 $count = mysql_num_rows($query2);
 if ($count == 0) {
  fetchTemplate("noforums");
 }
}
fetchTemplate("endcat");

fetchTemplate("footer");
?>